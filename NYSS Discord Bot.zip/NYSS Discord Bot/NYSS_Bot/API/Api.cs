﻿using NYSS_Bot.Helpers;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace NYSS_Bot.API
{
    public abstract class Api
    {
        protected static HttpClient _httpClient;
        static Api()
        {
            _httpClient = new HttpClient();
        }

        /// <summary>
        /// Метод, реализующий запрос к API
        /// </summary>
        /// /// <param name="sourse">Путь к API</param>
        /// <param name="apiMethod">Метод API</param>
        /// <param name="reqMethod">Метод запроса (Get, Post или Delete)</param>
        /// <param name="tokenPrefix">Префикс перед токеном</param>
        /// <param name="token">Токен</param>
        /// <param name="data">Информация, которую необходимо передать</param>
        /// <param name="src">Сериализованное представление приглашённых пользователей</param>
        /// <returns>Ответ сервера</returns>
        protected static async Task<string> ApiRequestAsync(string sourse, string apiMethod, HttpMethod reqMethod, 
            string tokenPrefix, string token, JsonObject data, string src=null)
        {
            string response = "";
            _httpClient.BaseAddress = new Uri(sourse);
            StringContent content= null;

            if (data != null)
            {
                content = new StringContent(data.ToString(), Encoding.UTF8, "application/json");
            }
            else if (!string.IsNullOrEmpty(src))
            {
                content = new StringContent(src, Encoding.UTF8, "application/json");
            }

            try
            {
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(tokenPrefix, token);
                _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (reqMethod == HttpMethod.Post)
                {
                    var serverResponce = await _httpClient.PostAsync(apiMethod, content);
                    response = await serverResponce.Content.ReadAsStringAsync();
                }
                else if (reqMethod == HttpMethod.Get)
                {
                    response = await _httpClient.GetStringAsync(apiMethod);
                }
                else if (reqMethod == HttpMethod.Delete)
                {
                    var request = new HttpRequestMessage
                    {
                        Content = new StringContent(data.ToString().Remove(0,1), Encoding.UTF8, "application/json"),
                        Method = HttpMethod.Delete,
                        RequestUri = new Uri(_httpClient.BaseAddress, apiMethod)
                    };
                    var serverResponce = await _httpClient.SendAsync(request);
                    response = await serverResponce.Content.ReadAsStringAsync();
                }
            }
            catch (Exception e)
            {
                Logger.Push("ApiRequest Exception", e.Message);
            }
            finally
            {
                _httpClient.Dispose();
                _httpClient = new HttpClient();
            }

            Logger.Push("ApiRequest", response);

            return response;
        }


    }
}
