﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using NYSS_Bot.Model;
using RestSharp;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace NYSS_Bot.API
{
    public sealed class DiscordApi : Api
    {
        private static string _token;
        private static string _channelId;

        static DiscordApi()
        {
            var config = new ConfigurationBuilder().AddUserSecrets<BotSecrets>().Build();
            config.Providers.First().TryGet("Token", out _token);
            config.Providers.First().TryGet("MainTextChannelId", out _channelId);
        }

        /// <summary>
        /// Метод, реализующий запрос к API дискорда
        /// </summary>
        /// <param name="reqMethod">Метод запроса (Get или Post)</param>
        /// <param name="apiMethod">Метод API</param>
        /// <param name="data">Информация, которую необходимо передать</param>
        /// <returns>Ответ сервера</returns>
        private static async Task<string> DiscordRequestAsync(HttpMethod reqMethod, string apiMethod, JsonObject data)
        {
            return await ApiRequestAsync("https://discordapp.com/api/", apiMethod, reqMethod, "Bot", _token, data);
        }

        /// <summary>
        /// Метод, генерирующий ссылку-приглашение на сервер
        /// </summary>
        /// <returns>Новая одноразовая бессрочная ссылка</returns>
        internal static async Task<string> CreateInviteUrlAsync()
        {
            var data = (dynamic)new JsonObject();
            data.access_token = _token;
            data.unique = true;

            var output = await DiscordRequestAsync(HttpMethod.Post, $"channels/{_channelId}/invites", data);
            var rawJson = JObject.Parse(output);

            string result = "https://discord.gg/";
            result += rawJson.SelectToken("code").ToString();

            return result;
        }

        /// <summary>
        /// Метод, генерирующий N ссылок
        /// </summary>
        /// <param name="urlsCount">Количество ссылок, которое нужно создать</param>
        /// <returns>Коллекция из N ссылок</returns>
        public static IEnumerable<string> GetInviteUrls(int urlsCount)
        {
            var balancer = new RequestBalancer(5, 13000, 400, CreateInviteUrlAsync);
            return balancer.Execute(urlsCount);
        }
    }
}
