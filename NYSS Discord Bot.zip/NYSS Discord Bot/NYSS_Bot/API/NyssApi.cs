﻿using Microsoft.Extensions.Configuration;
using NYSS_Bot.API;
using NYSS_Bot.Model;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using NYSS_Bot.Helpers;

namespace NYSS_Bot
{
    public sealed class NyssApi : Api
    {
        private static string _token = "";

        /// <summary>
        /// Метод, реализующий запрос к API портала
        /// </summary>
        /// <param name="reqMethod">Метод запроса (Get, Post или Delete)</param>
        /// <param name="apiMethod">Метод API</param>
        /// <param name="data">Информация, которую необходимо передать</param>
        /// <returns>Ответ сервера</returns>
        private static async Task<string> NyssRequestAsync(HttpMethod reqMethod, string apiMethod, JsonObject data, string src = null)
        {
            return await ApiRequestAsync("https://nyss.pro/discord/", apiMethod, reqMethod, "Bearer", _token, data, src);
        }

        /// <summary>
        /// Производит расссылку приглашений
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static async Task<string> SendEmailAsync(string data)
        {
            return await NyssRequestAsync(HttpMethod.Post, @"email/invite", null, data);
        }

        /// <summary>
        /// Метод, получающий расписание лекций с портала.
        /// Если получить расписание не удалось, возвращает список, содержащий экземпляр Schedule со значениями
        /// Lection = "0_0", Date = DateTime.MinValue.
        /// </summary>
        public static async Task<List<Lesson>> GetScheduleAsync()
        {
            string jsonScheduleResponse = await NyssRequestAsync(HttpMethod.Get, "set/schedule", new JsonObject());
            ScheduleResponseModel scheduleResponse = JsonConvert.DeserializeObject<ScheduleResponseModel>(jsonScheduleResponse);

            if (scheduleResponse == null)
            {
                Logger.Push("NullPointerException", "Failed to get response with schedule from nyss portal!");
                scheduleResponse.Schedule.Add(new Lesson() { Lection = "0_0", Date = DateTime.MinValue });
            }

            return scheduleResponse.Schedule;
        }

        /// <summary>
        /// Метод, реализующий запрос на авторизацию бота на портале
        /// </summary>
        public static async void AuthAsync()
        {
            string password;
            string email;
            var config = new ConfigurationBuilder().AddUserSecrets<BotSecrets>().Build();
            config.Providers.First().TryGet("BotPassword", out password);
            config.Providers.First().TryGet("BotEmail", out email);

            var data = new JsonObject() as dynamic;
            data.email = email;
            data.password = password;
            string res1 = await NyssRequestAsync(HttpMethod.Post, "authenticate", data);

            string res = res1.Substring(10);
            res = res.Remove(res.Length - 2);
            _token = res;
        }

        public static async Task<string> ValidateAsync(string code, string id)
        {
            var data = new JsonObject() as dynamic;
            data.code = code;
            data.discordId = id;

            return await NyssRequestAsync(HttpMethod.Post, "validate", data);
        }

        public static async Task<IEnumerable<User>> GetUsersAsync()
        {
            string result = await NyssRequestAsync(HttpMethod.Get, @"set/list", null);

            result = result.Replace("name", "Name");
            result = result.Replace("surName", "Surname");
            result = result.Replace("email", "Mail");
            result = result.Replace("level", "Level");
            result = result.Replace("totalExerciseCount", "TotalExerciseCount");
            result = result.Replace("lastOpenedLecture", "LastOpenedLecture");

            return System.Text.Json.JsonSerializer.Deserialize<List<User>>(result);
        }

        /// <summary>
        /// Метод, реализующий запрос на блокировку пользователя на портале
        /// </summary>
        public static async Task<string> BlockUserAsync(ulong id)
        {
            var data = new JsonObject() as dynamic;
            data.discordId = id.ToString();

            return await NyssRequestAsync(HttpMethod.Delete, @"set/block", data);
        }

        /// <summary>
        /// Метод осуществляет сбор значений на сервере до значений по умолчанию
        /// </summary>
        /// <returns></returns>
        public static async Task<string> ResetAsync()
        {
            return await NyssRequestAsync(HttpMethod.Get, "set/refresh", null);
        }
    }
}