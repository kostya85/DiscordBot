﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NYSS_Bot.API;
using RestSharp;

namespace NYSS_Bot.API
{
    /// <summary>
    /// Класс для оптимизации запросов к различным API
    /// </summary>
    public class RequestBalancer
    {
        private int _requestCount;
        private int _interval;
        private int _defaultInterval;
        private Func<Task<string>> _request;

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="requestCount">Количество запросов, которые можно сделать без задержки</param>
        /// <param name="interval">Перерыв между группами запросов (в мс)</param>
        /// <param name="defauleInterval">Перерыв между любыми запросами (в мс)</param>
        /// <param name="request">Запрос, который надо оптимизировать</param>
        public RequestBalancer(int requestCount, int interval, int defauleInterval, Func<Task<string>> request)
        {
            _requestCount = requestCount;
            _interval = interval;
            _defaultInterval = defauleInterval;
            _request = request;
        }

        public IEnumerable<string> Execute(int count)
        {
            int checker = 0;
            for (int i = 0; i < count; i++)
            {
                Thread.Sleep(_defaultInterval);

                yield return _request().Result;
                checker++;

                if (checker == _requestCount)
                {
                    checker = 0;
                    Thread.Sleep(_interval);
                }
            }
        }

    }
}