﻿using Discord;
using Discord.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NYSS_Bot.Attributes
{
    public class CheckRoleAttribute : PreconditionAttribute
    {
        private List<string> _roles;

        public CheckRoleAttribute(params string[] roles)
        {
            _roles = new List<string>(roles);
        }

        /// <summary>
        /// Выдает разрешение на использование команды
        /// </summary>
        /// <param name="context"></param>
        /// <param name="command"></param>
        /// <param name="services"></param>
        /// <returns></returns>
        public override async Task<PreconditionResult> CheckPermissionsAsync(ICommandContext context, CommandInfo command, IServiceProvider services)
        {
            IGuildUser user = Bot.Guild.Users.FirstOrDefault(x => x.Id == context.User.Id);
            if (user != null)
            {
                var discordRoles = Bot.Guild.Roles.Where(gr => _roles.Any(r => gr.Name == r));

                foreach (var role in discordRoles)
                {
                    var userInRole = user.RoleIds.Any(ri => ri == role.Id);

                    if (userInRole)
                    {
                        return await Task.FromResult(PreconditionResult.FromSuccess());
                    }
                }
            }
            return await Task.FromResult(PreconditionResult.FromError("У Вас не прав на использование этой команды"));
        }
    }
}
