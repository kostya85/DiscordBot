﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NYSS_Bot.Commands;
using NYSS_Bot.Helpers;
using NYSS_Bot.Helpers.Distribution.Messages;
using NYSS_Bot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace NYSS_Bot
{
    public class Bot
    {
        internal static SocketGuild Guild { get; private set; }
        private static DiscordSocketClient _client;
        private CommandService _commands;
        private IServiceProvider _services;
        private string _token;

        static Bot()
        {
            NyssApi.AuthAsync();
        }

        /// <summary>
        /// Конструктор класса Bot
        /// </summary>
        /// <param name="token">Токен сервера</param>
        public Bot(string token)
        {
            _token = token;
        }

        /// <summary>
        /// Инициализация, авторизация и запуск клиента бота 
        /// </summary>
        public async Task MainAsync()
        {
            _client = new DiscordSocketClient();
            _commands = new CommandService();

            _services = new ServiceCollection()
                .AddSingleton(_client)
                .AddSingleton(_commands)
                .BuildServiceProvider();

            _client.Log += HandlePrintCurrentLogAsync;
            _client.Ready += HandleGetGuild;            

            await RegisterCommandsAsync();
            await _client.LoginAsync(TokenType.Bot, _token);
            await _client.StartAsync();

            List<Lesson> list = await NyssApi.GetScheduleAsync();
            List<DateTime> lectureDates = new List<DateTime>();
            List<int> courseNumbers = new List<int>();
            List<int> lections = new List<int>();

            for (int i = 0; i < list.Count; i++)
            {
                lectureDates.Add(list[i].Date);
                courseNumbers.Add(Convert.ToInt32(list[i].Lection.Split('_')[0]));
                lections.Add(Convert.ToInt32(list[i].Lection.Split('_')[1]));
            }

            LessonsTimer.StartOfClasses = lectureDates;
            LessonsTimer.StartCourse(_client, lectureDates,courseNumbers, lections);

            Scheduler.Instance.ScheduleTask(lectureDates.Last().AddDays(360),
                                            new TimeSpan(0, 0, 0, 0, -1), EndCourseTimerAsync);

            await Task.Delay(-1);
        }

        /// <summary>
        /// Вызов удаления всех участников по завершению курса
        /// </summary>
        private async void EndCourseTimerAsync()
        {
            Console.WriteLine("Окончание курса" + DateTime.Now);

            foreach (var user in User.userList)
            {
                var discordUser = Guild.GetUser(user.Id);
                if (discordUser != null)
                {
                    await BaseCommands.MessageForUser(discordUser, "В связи с окончанием курса Вы были удалены с сервера.");
                    await discordUser.KickAsync();
                }
            }
        }

        /// <summary>
        /// Регистрация обработчика полученных сообщений и команд в клиенте
        /// </summary>
        public async Task RegisterCommandsAsync()
        {
            _client.MessageReceived += HandleCommandAsync;
            _client.MessageUpdated += HandleMessageUpdatedAsync;
            _client.UserJoined += HandleConnectedAsync;
            _client.UserLeft += HandleKickUser;
            await _commands.AddModulesAsync(Assembly.GetEntryAssembly(), _services);
        }

        /// <summary>
        /// Назначает роль неавторизованного пользователя и запускает таймер для авторизации
        /// </summary>
        /// <param name="user">Присоединившийся пользователь</param>
        /// <returns></returns>
        private async Task HandleConnectedAsync(SocketGuildUser user)
        {
            var role = (user as IGuildUser).Guild.Roles.FirstOrDefault(x => x.Name == "unauthorized");
            if (!user.Roles.Contains(role) & role != null)
            {
                string name = "Неизвестный";
                await user.AddRoleAsync(role);

                if (!user.Roles.Contains(role))
                {
                    await user.AddRoleAsync(role);
                    await user.ModifyAsync(x => x.Nickname = name);
                    await BaseCommands.MessageForUser(user as IGuildUser, "Добро пожаловать на сервер!\n" +
                        "В течении 2х часов Вы должны отправить мне ключ, высланный Вам на почту." +
                        "Для ввода пароля используйте команду: !key ЗДЕСЬ_ВАШ_КЛЮЧ");
                }

                var unauthorizedUser = new User() { Id = user.Id, Name = name };
                unauthorizedUser.StartKickTimer();
                User.unauthorized.Add(unauthorizedUser);

                Logger.Push("User connected", "Имя: " + user.Username + ". Роль: " + role.Name);
            }
        }

        /// <summary>
        /// Метод, получающий гильдию сервера
        /// </summary>
        private Task HandleGetGuild()
        {
            if (Guild == null)
            {
                Guild = _client.Guilds.First();
            }

            return Task.CompletedTask;
        }

        /// <summary>
        /// Метод, блокирующий пользователя на портале nyss.
        /// </summary>
        /// <param name="user">Объект, олицетворяющий пользователя.</param>
        private async Task HandleKickUser(SocketGuildUser user)
        {
            await NyssApi.BlockUserAsync(user.Id);
        }

        /// <summary>
        /// Логирование действий работы клиента
        /// </summary>
        /// <param name="arg">Сообщение для записи в лог</param>
        private async Task HandlePrintCurrentLogAsync(LogMessage arg)
        {
            Logger.Push("Client", arg.Message);
            await Task.CompletedTask;
        }

        /// <summary>
        /// Обработка изменённого сообщения с применением фильтра
        /// </summary>
        /// <param name="_"></param>
        /// <param name="message">Изменённое сообщение</param>
        /// <param name="channel">Канал, в котором изменено сообщение</param>
        /// <returns></returns>
        private async Task HandleMessageUpdatedAsync(Cacheable<Discord.IMessage, ulong> _, SocketMessage message, ISocketMessageChannel channel)
        {
            if (message.Content == null || message.Author.IsBot)
            {
                return;
            }

            if (message is SocketUserMessage == false)
            {
                return;
            }

            var context = new SocketCommandContext(_client, message as SocketUserMessage);

            await CheckMessage(context);
        }

        /// <summary>
        /// Обработка полученного сообщения с выделением в нём команды
        /// </summary>
        /// <param name="arg">Сообщение, полученное клиентом бота</param>
        public async Task HandleCommandAsync(SocketMessage arg)
        {
            if (arg.Author.IsBot)
            { 
                return;
            }

            if (arg is SocketUserMessage == false) 
            { 
                return; 
            }

            var message = arg as SocketUserMessage;
            var context = new SocketCommandContext(_client, message);
            int argPos = 0;

            if (await CheckMessage(context))
            {
                return;
            }

            if (message.HasStringPrefix("!", ref argPos))
            {
                var result = await _commands.ExecuteAsync(context, argPos, _services);
                if (!result.IsSuccess)
                {
                    Logger.Push("IsSuccess Error!", result.Error.ToString());
                }
                else
                {
                    Logger.Push(message.Author.Username, message.Content);
                }
            }
        }

        /// <summary>
        /// Метод проверяет сообщение на запрещённый контент, если он есть,
        /// сообщение удаляется, пользователю отправляется уведомлении о нарушении.
        /// </summary>
        /// <param name="context">Контекст сообщения</param>
        /// <returns>true, если контент запрещен</returns>
        private async Task<bool> CheckMessage(SocketCommandContext context)
        {
            if (ProfanityFilter.FilterMessage(context.Message.Content, 
                context.Client.GetGuild(Guild.Id).GetUser(context.User.Id).GuildPermissions.Administrator))
            {
                try
                {
                    User.userList.Find(x => x.Id == context.User.Id).ViolatedRulesCount++;
                }
                catch (Exception)
                {
                    Logger.Push("CheckMessage", "Пользователь с таким Id не найден.");
                }

                Send.DirectMessage("Вы нарушили правила сервера! Ваше сообщение было удалено.", context.User.Id);
                await context.Message.DeleteAsync();

                return true;
            }

            return false;
        }
    }
}
