﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Microsoft.Extensions.Configuration;
using NYSS_Bot.Attributes;
using NYSS_Bot.Helpers;
using NYSS_Bot.Helpers.Distribution;
using NYSS_Bot.Model;
using NYSS_Bot.Model.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace NYSS_Bot.Commands
{
    public class AdminCommands : BaseCommands
    {
        private static string _mainVoiceChannelId;
        private static string _firstChannelId;
        private static string _secondChannelId;
        private static string _thirdChannelId;

        static AdminCommands()
        {
            var config = new ConfigurationBuilder().AddUserSecrets<BotSecrets>().Build();
            config.Providers.First().TryGet("MainVoiceChannelId", out _mainVoiceChannelId);
            config.Providers.First().TryGet("FirstChannelId", out _firstChannelId);
            config.Providers.First().TryGet("SecondChannelId", out _secondChannelId);
            config.Providers.First().TryGet("ThirdChannelId", out _thirdChannelId);
        }

        /// <summary>
        /// Обработчик команды "Admin"
        /// </summary>
        [Command("admin")]
        [CheckRole("administrator")]
        [RequireContext(ContextType.DM)]
        public async Task AdminAsync()
        {
            await ReplyAsync("Ты админ!");
        }


        /// <summary>
        /// Обработчик команды "contactinfo"
        /// Подписывает пользователя на рассылку
        /// информации о юзерах с некорректной
        /// контактной информацией
        /// </summary>
        [Command("contactinfo")]
        [CheckRole("administrator")]
        [RequireContext(ContextType.DM)]
        public Task ContactInfoAsync()
        {
            if (ContactDataValidator.MessageTimer == null)
            {
                ContactDataValidator.MessageTimer = new CustomMessageTimer(Context.Channel, new ContactDataValidator());
            }
            else
            {
                ContactDataValidator.MessageTimer.Restart();
            }

            return Task.CompletedTask;
        }

        /// <summary>
        /// Обработчик команды "contactinfo stop|restart"
        /// Подписывает/Отписывает пользователя от
        /// соответствующей рассылки
        /// </summary>
        [Command("contactinfo")]
        [CheckRole("administrator")]
        [RequireContext(ContextType.DM)]
        public async Task ContactInfoAsync(string arg)
        {
            if (Context.Channel is SocketDMChannel && (arg.ToLower() == "stop" || arg.ToLower() == "restart"))
            {
                if (ContactDataValidator.MessageTimer == null)
                {
                    await ReplyAsync("Таймер не был назначен. Вызовите !contactinfo");
                }
                else
                {
                    string reply = "Подписка ";
                    if (arg.ToLower() == "stop")
                    {
                        ContactDataValidator.MessageTimer.Stop();
                        reply += "отменена!";
                    }
                    if (arg.ToLower() == "restart")
                    {
                        ContactDataValidator.MessageTimer.Restart();
                        reply += "возобновлена!";
                    }
                    await ReplyAsync(reply);
                }
            }
            else
            {
                await ReplyAsync("Некорректный аргумент. Доступно: !stop или !restart");
            }
        }

        [Command("KickOutlaws")]
        [CheckRole("administrator")]
        [RequireContext(ContextType.DM)]
        public async Task KickOutlawsAsync()
        {
            foreach (var user in User.userList)
            {
                string kickReason;
                foreach (var rule in new RuleManager().CurrentRules)
                {
                    if (!rule.CheckFor(user, out kickReason))
                    {
                        var discordUser = Context.Client.GetGuild(Bot.Guild.Id).GetUser(user.Id);
                        if (discordUser != null)
                        {
                            await MessageForUser(discordUser, "Вы были удалены с сервера.\nПричина: " + kickReason);
                            await discordUser.KickAsync();
                        }
                        break;
                    }
                }
            }
        }

        [Command("addresourse")]
        [CheckRole("administrator")]
        [RequireContext(ContextType.DM)]
        public async Task AddResourseAsync(string resourse)
        {

            if (AllowedResources.AddResourse(resourse))
            {
                await ReplyAsync("Ссылка добавлена в список разрешенных ресурсов!");
            }
            else
            {
                await ReplyAsync("Произошла ошибка, не удалось добавить ссылку");
            }
        }

        [Command("deleteresourse")]
        [CheckRole("administrator")]
        [RequireContext(ContextType.DM)]
        public async Task DeleteResourseAsync(string number)
        {
            int n = 0;
            if (int.TryParse(number, out n))
            {
                if (AllowedResources.DeleteResourse(n))
                {
                    await ReplyAsync("Ссылка удалена!");
                    string allresourses = "";

                    for (int i = 0; i < AllowedResources.AllAllowedResourses.Count; i++)
                    {
                        allresourses += (i + 1) + ")  " + AllowedResources.AllAllowedResourses[i] + "\n";
                    }

                    var EmbedBuilder = new EmbedBuilder().WithDescription("Список разрешенных ресурсов\n\n" + allresourses);
                    Embed embed = EmbedBuilder.Build();
                    await ReplyAsync(embed: embed);
                }
                else
                {
                    await ReplyAsync("Произошла ошибка, не удалось удалить ссылку");
                }
            }
            else
            {
                await ReplyAsync("Введите номер удалаемой ссылки");
            }
        }

        /// <summary>
        /// Метод, собирающий всех участников в главном голосовом канале
        /// </summary>
        /// <returns></returns>
        [Command("union")]
        [CheckRole("administrator")]
        public async Task MoveEveryoneToMain()
        {
            foreach (var user in UnionUsers())
            {
                await user.ModifyAsync(x => x.ChannelId = ulong.Parse(_mainVoiceChannelId));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns>Возвращает коллекцию всех пользователей сервера, находящихся на голосовых каналах (работает быстрее, чем Guild.Users)</returns>
        private IEnumerable<SocketGuildUser> UnionUsers()
        {
            foreach (var user in Context.Guild.GetChannel(ulong.Parse(_mainVoiceChannelId)).Users.Union(
                                 Context.Guild.GetChannel(ulong.Parse(_firstChannelId)).Users.Union(
                                 Context.Guild.GetChannel(ulong.Parse(_secondChannelId)).Users.Union(
                                 Context.Guild.GetChannel(ulong.Parse(_thirdChannelId)).Users))))
            {
                yield return user;
            }
        }

        /// <summary>
        /// Метод, распределяющий всех пользователей по каналам, в зависимости от их уровня
        /// </summary>
        /// <returns></returns>
        [Command("formteams")]
        [CheckRole("administrator")]
        public async Task MoveToAnother()
        {
            Dictionary<int, ulong> dict = new Dictionary<int, ulong>()
            {
                {0, ulong.Parse(_firstChannelId) },
                {1, ulong.Parse(_secondChannelId) },
                {2, ulong.Parse(_thirdChannelId) }
            };

            var discordUsers = UnionUsers();
            //var nyssUsers =  await NyssApi.GetUsers();  --- пока заглушка, ибо NyssApi.GetUsers() возвращает коллекцию, где есть только email'ы
            //                                                а мне нужны имя, фамилия и уровень

            var nyssUsers = new List<User>()
            {
                new User() {Name = "Денис", Surname = "Добренко", Level = 1},
                new User(){Name = "Александр", Surname = "Грачев", Level = 2},
                new User(){Name = "Кoнcтантин", Surname = "Горбунов", Level = 3},
            };

            var users = new List<User>();

            foreach (var nyssUser in nyssUsers)
            {
                foreach (var discordUser in discordUsers)
                {
                    if (discordUser.Nickname == nyssUser.Name + " " + nyssUser.Surname ||
                       discordUser.Username == nyssUser.Name + " " + nyssUser.Surname)
                    {
                        var user = nyssUser;
                        user.Id = discordUser.Id;
                        users.Add(user);
                    }
                }
            }

            var teams = TeamFormer.GetTeams(users);

            for (int i = 0; i < teams.Length; i++)
            {
                foreach (var user in teams[i])
                {
                    var ds = discordUsers.Where(x => x.Id == user.Id).FirstOrDefault();

                    if (ds != default)
                    {
                        await ds.ModifyAsync(x => x.ChannelId = dict[i]);
                    }
                }
            }
        }

        /// <summary>
        /// Обработчик команды "invite"
        /// </summary>
        [Command("invite")]
        [CheckRole("administrator")]
        //[RequireContext(ContextType.DM)]
        public async Task Invite()
        {

            await ReplyAsync("Скачиваю список пользователей для отправки приглашений...");
            await ReplyAsync(await Sender.DownloadDataAsync());

            if (User.userList == null || User.userList.Count == 0)
            {
                await ReplyAsync("При отправке писем-приглашений произошла ошибка!");
            }
            else
            {
                await ReplyAsync("Начинаю генерацию ссылок-приглашений");

                var message = await Sender.SendMailAsync();
                if (message != null)
                {
                    await ReplyAsync("Генерация ссылок-приглашений прошла успешно!\nСписок для отправки рассылки:\n");
                    string response = "";
                    foreach (var e in message)
                    {
                       response+=("Пользователю " + e.Mail + " отправлен код " + e.Code + " и ссылка " + e.InviteLink+"\n\n");
                    }
                    await ReplyAsync(response);
                }
                else
                {
                    await ReplyAsync("При отправке писем-приглашений произошла ошибка!");
                }
            }
        }

        /// <summary>
        /// Обработчик команды "reset"
        /// </summary>
        [Command("reset")]
        [CheckRole("administrator")]        
        public async Task Reset()
        {
            var response = await NyssApi.ResetAsync();
            await ReplyAsync(response);
        }
    }
}
