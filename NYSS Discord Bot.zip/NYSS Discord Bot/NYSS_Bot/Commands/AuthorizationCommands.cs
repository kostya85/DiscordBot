﻿using System;
using System.Collections;
using System.Linq;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using NYSS_Bot.Attributes;
using NYSS_Bot.Commands;
using NYSS_Bot.Model;
using Newtonsoft.Json.Linq;
using NYSS_Bot.Helpers.Distribution.Messages;

namespace NYSS_Bot.Helpers
{
    public class AuthorizationCommands : BaseCommands
    {
        /// <summary>
        /// Авторизация пользователя по ключу.
        /// Если ключ верный, то происходит остановка таймера и удаление пользователя из списка неавторизованных.
        /// После чего ему присваивается роль "authorized"
        /// </summary>
        /// <param name="key">ключ активации Discord аккаунта</param>
        /// <returns></returns>
        [Command("key")]
        [CheckRole("unauthorized")]
        [RequireContext(ContextType.DM)]
        public async Task Key([Remainder] string key = null)
        {
            var user = Bot.Guild.GetUser(Context.User.Id);
            var role = user.Guild.Roles.FirstOrDefault(x => x.Name == "unauthorized");
            var adminRole = user.Guild.Roles.FirstOrDefault(x => x.Name == "administrator");
            if (role == null || adminRole == null)
            {
                await MessageForUser(user, "Не найдены роли на сервере. Обратитесь к администратору!");
                return;
            }

            if (user.Guild.Roles.Contains(role))
            {
                dynamic response = JObject.Parse(await NyssApi.ValidateAsync(key, user.Id.ToString()));
                if (response.name != null && response.surname != null)
                {
                    var unauthorizedUser = User.unauthorized.FirstOrDefault(x => x.Id == user.Id);
                    if (unauthorizedUser is User)
                    {
                        unauthorizedUser.StopKickTimer();
                        User.unauthorized.Remove(unauthorizedUser);
                    }
                    user = await ChangeNicknameAsync(user, response.name.ToString(), response.surname.ToString());
                    await SetRoleAsync(user, "authorized");
                    await DelRole(user, "unauthorized");
                    await MessageForUser(user, "Авторизация успешно пройдена!");
                    var admins = Bot.Guild.Users.Where(x => x.Roles.Contains(adminRole));
                    if (admins != null)
                    {
                        await MessageForUsers(admins, $"{response.name} {response.surname} успешно прошел авторизацию!");
                    }
                }
                else if (response.message != null)
                {
                    await MessageForUser(user, response.message.ToString());
                    Logger.Push(user.Username, response.message);
                }
            }
        }

        /// <summary>
        /// Меняет никнейм пользователя на сервере
        /// </summary>
        /// <param name="user"></param>
        /// <param name="newNicknameParts"></param>
        /// <returns></returns>
        public async Task<SocketGuildUser> ChangeNicknameAsync(SocketGuildUser user, params string[] newNicknameParts)
        {
            if (newNicknameParts is null || string.IsNullOrWhiteSpace(string.Join(" ", newNicknameParts)) || string.IsNullOrEmpty(string.Join(" ", newNicknameParts)))
            {
                await MessageForUser(user, "Кажется, Вы забыли указать новый никнейм!");
                return user;
            }

            var newNickname = String.Join(" ", newNicknameParts);

            if (user.Nickname == newNickname)
            {
                await MessageForUser(user, $"Вы уже и так {user.Nickname}, Вам не нужно менять свой никнейм!");
                return user;
            }

            var oldNickname = user.Nickname;

            try
            {
                await user.ModifyAsync(x => x.Nickname = newNickname);
                await MessageForUser(user, $"{oldNickname} теперь зовут {newNickname}!");
                return user;
            }
            catch (Exception e)
            {
                await Context.Channel
                    .SendMessageAsync
                    ($"Ой! Ошибочка вышла: {e}")
                    .ConfigureAwait(false);
                return user;
            }
        }

        /// <summary>
        /// Выдаёт пользователю роль "authorized"
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task SetRoleAsync(SocketGuildUser user, string roleName)
        {
            var role = Bot.Guild.Roles.FirstOrDefault(x => x.Name == roleName);

            if (role is null)
            {
                await MessageForUser(user, $"А, ой... на сервере ещё нет роли {roleName}! Добавьте её и повторите снова.");
                return;
            }

            if (user.Roles.Contains(role))
            {
                await MessageForUser(user, $"{user.Nickname} уже имеет роль {roleName}!");
                return;
            }

            await (user as IGuildUser).AddRoleAsync(role);
            await MessageForUser(user, $"Пользователь {user.Nickname} теперь имеет роль {roleName}!");
        }

        /// <summary>
        /// Убирает роль авторизованного пользователя
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task DelRole(SocketGuildUser user, string roleName)
        {
            var role = Bot.Guild.Roles.FirstOrDefault(x => x.Name == roleName);

            if (role is null)
            {
                await MessageForUser(user, $"А, ой... на сервере ещё нет роли {roleName}! Добавьте её и повторите снова.");
                return;
            }

            if (!user.Roles.Contains(role))
            {
                await MessageForUser(user, $"У пользователя {user.Nickname} и так нет роли \"{roleName}\" авторизован!");
                return;
            }

            await (user as IGuildUser).RemoveRoleAsync(role);
            await MessageForUser(user, $"У пользователя {user.Nickname} больше нет роли \"{roleName}\"!");
        }
    }
}
