﻿using Discord;
using Discord.Commands;
using NYSS_Bot.Helpers;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NYSS_Bot.Commands
{
    public class BaseCommands : ModuleBase<SocketCommandContext>
    {
        /// <summary>
        /// Метод для уведомления пользователя в личные сообщения
        /// </summary>
        /// <param name="user">Пользователь</param>
        /// <param name="text">Сообщение для пользователя</param>
        /// <returns></returns>
        public static async Task MessageForUser(IGuildUser user, [Remainder] string text)
        {
            var EmbedBuilderForUser = new EmbedBuilder().WithDescription($"{text}");
            Embed embedUser = EmbedBuilderForUser.Build();
            await user.SendMessageAsync(embed: embedUser);
            Logger.Push(user.Nickname, text);
        }

        /// <summary>
        /// Метод для уведомления списка пользователей в личные сообщения
        /// </summary>
        /// <param name="user">Пользователи, которых уведомляем</param>
        /// <param name="text">Сообщение для пользователя</param>
        /// <returns></returns>
        public static async Task MessageForUsers(IEnumerable<IGuildUser> users, [Remainder] string text)
        {
            foreach (var user in users)
            {
               await MessageForUser(user, text);
            }
        }
    }
}
