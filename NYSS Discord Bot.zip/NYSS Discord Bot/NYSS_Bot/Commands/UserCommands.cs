﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Microsoft.Extensions.Configuration;
using NYSS_Bot.Helpers;
using NYSS_Bot.Model;
using System;
namespace NYSS_Bot.Commands
{
    public class UserCommands : BaseCommands
    {
        /// <summary>
        /// Обработчик команды "hello"
        /// </summary>
        [Command("hello")]
        public async Task HelloAsync()
        {
            await ReplyAsync("Привет всем!");
        }

        [Command("allresourses")]
        public async Task ShowAllResoursesAsync()
        {
            string allresourses = "";
            for (int i = 0; i < AllowedResources.AllAllowedResourses.Count; i++)
            {
                allresourses += (i + 1) + ")  " + AllowedResources.AllAllowedResourses[i] + "\n";
            }

            var EmbedBuilder = new EmbedBuilder().WithDescription("Список разрешенных ресурсов\n\n" + allresourses);
            Embed embed = EmbedBuilder.Build();
            await ReplyAsync(embed: embed);
        }

        [Command("invite")]
        public async Task InviteAsync()
        {
            var eb = new EmbedBuilder();
            eb.WithTitle("Ошибка выполнения команды");
            eb.WithDescription(Context.User.Username + ", не твой уровень дорогой!");
            eb.WithImageUrl("https://pbs.twimg.com/media/EYzwV8yWAAADfQr.jpg");
            await Context.Channel.SendMessageAsync("", false, eb.Build());
        }
    }
}