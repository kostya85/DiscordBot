﻿using Discord.WebSocket;
using NYSS_Bot.Model;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NYSS_Bot.Helpers.Distribution
{

    /// <summary>
    /// Каждые сутки (время можно поменять) отправляет администратору информацию по ошибкам
    /// в контактной информации пользователей (если таковые имеются)
    /// В случае отписки от рассылки таймер останавливается методом Stop(),
    /// В случае подписки запускается методом Restart();
    /// </summary>
    public class ContactDataValidator : ISharable
    {
        private static HashSet<User> _invalidUsers = new HashSet<User>();
        public static CustomMessageTimer MessageTimer;

        public static bool IsEmailValid(User user)
        {
            if (user == null)
            {
                return false;
            }

            if (MailValidate(user.Mail))
            {
                if (_invalidUsers.Contains(user))
                {
                    _invalidUsers.Remove(user);
                }

                return true;
            }

            if (!_invalidUsers.Contains(user))
            {
                _invalidUsers.Add(user);
            }

            return false;
        }
        public static bool IsEmailValid(string email)
        {
            if (User.userList.Find(x => x.Mail == email) == null)
            {
                if (MailValidate(email))
                {
                    return true;
                }

                return false;
            }

            return IsEmailValid(User.userList.Find(x => x.Mail == email));
        }

        public static string ShareInfo()
        {
            if (_invalidUsers.Count == 0)
            {
                return "У всех пользователей указаны корректные контактные данные";
            }

            string message = "Список пользователей с некорретными контактными данными:\n";

            foreach (var entry in _invalidUsers)
            {
                message += $"{entry.Name} {entry.Surname} : {entry.Mail}\n";
            }

            return message;
        }

        public async Task ShareAsync(ISocketMessageChannel channel)
        {
            await channel.SendMessageAsync(ShareInfo());
        }

        private static bool MailValidate(string mail)
        {
            try
            {
                var email = new System.Net.Mail.MailAddress(mail);
                Regex re = new Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                                     @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                                     @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", 
                                     RegexOptions.IgnoreCase);

                if (re.IsMatch(mail))
                {
                    return true;
                }
            }
            catch (System.Exception)
            {
                return false;
            }

            return false;
        }
    }
}
