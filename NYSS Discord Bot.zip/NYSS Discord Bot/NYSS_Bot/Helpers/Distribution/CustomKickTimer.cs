﻿using NYSS_Bot.Model;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace NYSS_Bot.Helpers.Distribution
{
    /// <summary>
    /// Инициализируется при создании пользователя (User). Если пользователь
    /// пройдет авторизацию в течение 2х часов - таймер останавливается
    /// (вызывается метод Stop() у таймера юзера в методе, отвечающем за аутентификацию)
    /// Если же таймер сработал, а пользователь всё еще не авторизовался - вызовется комада по
    /// его удалению с сервера.
    /// </summary>
    public class CustomKickTimer : CustomTimer
    {
        private bool _started = false;
        private User _user;
        public CustomKickTimer(User user)
        {
            _user = user;
            TimeRepeatCycle = TimeSpan.FromMinutes(120);
            _timer = new Timer(
                async _ => { await AutoKickAsync(); },
                _timerCanceller, TimeoutBeforeSending, TimeRepeatCycle);
        }

        public async Task AutoKickAsync()
        {
            if (_started)
            {
                await _user.AutoKickAsync();
                Stop();
            }
            else
            {
                _started = true;
            }
        }

        public override void Stop()
        {
            _timerCanceller.Stopped = true;
            base.Stop();
            _timer.Dispose();
        }
    }
}
