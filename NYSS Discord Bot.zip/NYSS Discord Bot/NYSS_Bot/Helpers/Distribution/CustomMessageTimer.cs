﻿using Discord.WebSocket;
using System.Threading;

namespace NYSS_Bot.Helpers.Distribution
{
    /// <summary>
    /// Позволяет легко создавать рассылки в личные сообщения пользователям.
    /// Можно задать интервал для появления новых сообщений и таймаут их отправки.
    /// Каждый таймер привязан к сущности, наследуемой от ISharable.
    /// Таймер не содержит никакой дополнительной логики для сообщений,
    /// он просто вызывает метод Share() от класса, к которому привязан.
    /// Чтобы начать рассылку, требуется создать экземпляр таймера и передать ему канал
    /// </summary>
    public class CustomMessageTimer : CustomTimer
    {
        private ISharable _notificator;
        public CustomMessageTimer(ISocketMessageChannel channel, ISharable sharable)
        {
            _notificator = sharable;
            _timer = new Timer(
                async _ => { await _notificator.ShareAsync(channel); },
                null, TimeoutBeforeSending, TimeRepeatCycle);
        }
    }
}
