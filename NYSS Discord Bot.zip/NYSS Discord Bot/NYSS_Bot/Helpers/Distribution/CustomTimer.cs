﻿using Discord;
using System;
using System.Threading;

namespace NYSS_Bot.Helpers.Distribution
{
    /// <summary>
    /// Абстрактный класс для всех таймеров. Всю доп логику в наследниках
    /// следует прописывать в конструкторах классов.
    /// TimeoutBeforeSending - время после того, как таймер сработал, но перед тем, как выполнится действие
    /// TimeRepeatCycle - время одного круга таймера.
    /// Если извне были изменены эти два свойства, чтобы их применить нужно просто
    /// рестартнуть таймер методом Restart()
    /// </summary>
    public abstract class CustomTimer
    {
        protected Timer _timer;
        protected TimerCanceller _timerCanceller = new TimerCanceller();

        public TimeSpan TimeoutBeforeSending { get; set; } = TimeSpan.FromMilliseconds(0);

        public TimeSpan TimeRepeatCycle { get; set; } = TimeSpan.FromDays(1);

        public virtual void Stop()
        {
            _timer.Change(Timeout.Infinite, Timeout.Infinite);
        }

        public void Restart()
        {
            _timer.Change(TimeoutBeforeSending, TimeRepeatCycle);
        }
    }

    /// <summary>
    /// Это как object lock чтобы корректно "остановить" таймер
    /// изнутри (из callback). Если такая функция необходима, перед 
    /// вызовом Stop() в callback нужно изменить значение свойства
    /// Stopped на true
    /// </summary>
    public class TimerCanceller
    {
        public bool Stopped { get; set; } = false;
    }
}
