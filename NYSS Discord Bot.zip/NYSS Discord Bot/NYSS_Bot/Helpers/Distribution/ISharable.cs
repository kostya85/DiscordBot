﻿using Discord.WebSocket;
using System.Threading.Tasks;

namespace NYSS_Bot.Helpers.Distribution
{
    public interface ISharable
    {
        public Task ShareAsync(ISocketMessageChannel channel);
    }
}
