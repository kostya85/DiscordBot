﻿using Discord;
using NYSS_Bot.Model;
using System.Linq;

namespace NYSS_Bot.Helpers.Distribution.Messages
{
    /// <summary>
    /// Класс реализует отправку приватных сообщений пользователю в дискорде
    /// </summary>
    internal class DiscordDirectMessageSender : IMessageSender
    {
        /// <summary>
        /// Метод отправляет личное сообщение пользователю
        /// </summary>
        /// <param name="message">Сообщение</param>
        /// <param name="userId">id пользователя</param>
        public async void SendAsync(IMessage message, ulong userId)
        {
            var guildUser = Users.All.FirstOrDefault(user => user.Id == userId);

            var embed = new EmbedBuilder()
                    .WithAuthor(message.Author)
                    .WithTitle(message.Title)
                    .WithDescription(message.Body);

            await guildUser.SendMessageAsync("", false, embed.Build());
        }

    }
}

