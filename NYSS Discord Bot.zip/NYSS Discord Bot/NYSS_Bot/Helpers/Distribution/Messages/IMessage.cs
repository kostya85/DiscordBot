﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_Bot.Helpers.Distribution.Messages
{
    /// <summary>
    /// Интерфейс для представления сообщений
    /// </summary>
    public interface IMessage
    {
        string Title { get; }

        string Body { get; }

        string Author { get; }
    }
}
