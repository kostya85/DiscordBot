﻿using System;
using System.Collections.Generic;
using System.Text;
using NYSS_Bot.Model;

namespace NYSS_Bot.Helpers.Distribution.Messages
{
    /// <summary>
    /// Интерфейс для отправки пользователю сообщений
    /// </summary>
    public interface IMessageSender
    {
        /// <summary>
        /// Отправляет сообщение пользователю
        /// </summary>
        /// <param name="message">Сообщение</param>
        /// <param name="userId">id пользователя</param>
        void SendAsync(IMessage message, ulong userId);
    }
}
