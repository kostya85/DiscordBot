﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_Bot.Helpers.Distribution.Messages
{
    /// <summary>
    /// Класс <c>Message</c> реализует интерфейс <c>IMessage</c>.
    /// Класс является представлением сообщения
    /// </summary>
    public class Message : IMessage
    {
        public string Title { get; }
        public string Body { get; } 
        public string Author { get; }

        public Message(string title, string body, string author = "")
        {
            Title = title;
            Body = body;
            Author = author;
        }
    }
}
