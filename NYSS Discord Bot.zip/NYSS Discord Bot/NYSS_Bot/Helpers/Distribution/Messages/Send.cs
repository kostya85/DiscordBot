﻿using System;
using System.Collections.Generic;
using NYSS_Bot.Model;

namespace NYSS_Bot.Helpers.Distribution.Messages
{
    /// <summary>
    /// Статический класс, который содержит методы для отправки сообщений разных типов
    /// </summary>
    public static class Send
    {
        private static DiscordDirectMessageSender sender = new DiscordDirectMessageSender();

        /// <summary>
        /// Отправляет приватное сообщение пользователю
        /// </summary>
        /// <param name="message">Сообщение</param>
        /// <param name="userId">id пользователя</param>
        public static void DirectMessage(IMessage message, ulong userId)
        {
            sender.SendAsync(message, userId);
        }

        /// <summary>
        /// Отправляет приватное сообщение пользователю
        /// </summary>
        /// <param name="text">Тело сообщения</param>
        /// <param name="userId">id пользователя</param>
        public static void DirectMessage(string text, ulong userId)
        {
            DirectMessage(new Message(null, text), userId);
        }

        /// <summary>
        /// Отправляет приватное сообщение пользователю
        /// </summary>
        /// <param name="title">Заголовок сообщения</param>
        /// <param name="body">Тело сообщения</param>
        /// <param name="author">Автор сообщения</param>
        /// <param name="userId">id пользователя</param>
        public static void DirectMessage(string title, string body, string author, ulong userId)
        {
            DirectMessage(new Message(title, body, author), userId);
        }

        public static void DirectMessageToAll(string text, Predicate<ulong> predicate)
        {
            var message = new Message("", text);

            Users.ForEachWhere(predicate, id =>
            {
                DirectMessage(message, id);
            });
        }

        public static void DirectMessageToAll(string text)
        {
            DirectMessageToAll(text, _ => true);
        }

        public static void DirectMessageToAdmins(string text)
        {
            DirectMessageToAll(text, Users.IsAdmin);
        }

        public static void DirectMessageToNotAdmins(string text)
        {
            DirectMessageToAll(text, id => !Users.IsAdmin(id));
        }
    }
}
