﻿using Microsoft.Extensions.Configuration;
using NYSS_Bot.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace NYSS_Bot.Helpers
{
    /// <summary>
    /// Данный класс позволяет кодировать и декодировать ссылку-приглашение на сервер
    /// </summary>
    public class Encoder
    {
        static char[] _alphabet = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789".ToCharArray();
        /// <summary>
        /// Кодирование ссылки путем добавления в начало и конец 3 случайно сгенерированных символа
        /// </summary>
        public static string Encode(string src)
        {
            src = src.Replace(@"https://discord.gg/", "");
            string key = GenerateKey(6);
            Console.WriteLine(key.Substring(0, 3) + src + key.Substring(3));

            return key.Substring(0, 3) + src + key.Substring(3);
        }

        /// <summary>
        /// Извлечение ссылки из введенного пользователем при входе на сервер кода путем удаления из начала и конца 3 символов
        /// </summary>
        public static string Decode(string src)
        {
            string res = "";
            for(int i = 3; i < src.Length - 3; i++)
            {
                res += src[i];
            }

            return res;
        }

        /// <summary>
        /// Генерация ключа, состоящего из 6 случайных символов
        /// </summary>
        public static string GenerateKey(int count)
        {
            string res = "";
            Random r = new Random();

            for(int i = 0; i < count; i++)
            {
                res += _alphabet[r.Next(0, _alphabet.Length)];
            }

            return res;
        }
    }
}
