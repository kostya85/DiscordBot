﻿using System;
using System.Collections.Generic;
using System.Threading;
using Discord;
using Discord.WebSocket;
using NYSS_Bot.Model;
using NYSS_Bot.Helpers.Distribution.Messages;

namespace NYSS_Bot.Helpers
{
    
    class LessonsTimer
    {
        /// <summary>
        /// Таймер, отслеживающий расписание занятий
        /// </summary>
        public static Timer timer;
        private static DiscordSocketClient _client;
        /// <summary>
        /// Список с датами/временем проведения занятий
        /// </summary>
        public static List<DateTime> StartOfClasses { get; set; } = new List<DateTime>();
        /// <summary>
        /// Номер курса, который должен быть открыт на портале к соответствующему занятию
        /// </summary>
        public static List<int> sections = new List<int>();
        /// <summary>
        /// Номер лекции, которая должна быть открыта к соответствующему занятию
        /// </summary>
        public static List<int> lections = new List<int>();

        private static AutoResetEvent _autoEvent = new AutoResetEvent(false);
        private static int _lessonNumber = 0;
        private static int _lessonMin = 0;
        private static int _lessonDuration = 180;

        /// <summary>
        /// Словарь, содержащий статистику о том, чтолько минут человек присутствует на занятии
        /// </summary>
        private static Dictionary<ulong, int> _statistics = new Dictionary<ulong, int>();
        /// <summary>
        /// Метод, запускающий таймер
        /// </summary>
        /// <param name="client">Экземпляр DiscordSocketClient из класса Bot</param>
        /// <param name="dates">Список дат начал занятий</param>
        /// <param name="courseNumbers">Список номеров курсов, которые должны быть открыты к началу занятий</param>
        /// <param name="lectionNumbers">Список номеров лекций, которые должны быть открыты к началу занятий</param>
        public static void StartCourse(DiscordSocketClient client, List<DateTime> dates,List<int> courseNumbers,List<int> lectionNumbers )
        {
            _client = client;
            StartOfClasses = dates;
            sections = courseNumbers;
            lections = lectionNumbers;
            for (int i = 0; i < StartOfClasses.Count; i++)
            {
                if (DateTime.Now < StartOfClasses[i])
                {
                    _lessonNumber = i;
                    timer = new Timer(CheckSchedule, _autoEvent,(60- DateTime.Now.Second)*1000, 60000);
                    break;
                }
            }
        }
        /// <summary>
        /// Метод, срабатывающий каждую минуту и начинающий сбор статистики посещения, если по расписанию должно начаться занятие
        /// </summary>
        
        static void CheckSchedule(Object o)
        {
            
            if (DateTime.Now >= StartOfClasses[_lessonNumber])
            {
                if (_lessonMin == 0)
                {
                    BacklogAlert();
                }

                _lessonMin++;
                CollectStatistics();

                if (_lessonMin == _lessonDuration)
                {
                    _lessonMin = 0;
                    _lessonNumber++;
                    SendSatistics();
                    
                    if (_lessonNumber== StartOfClasses.Count - 1)
                    {
                        CloseToEndOfCourseAlert();
                    }
                }

                if (_lessonNumber >= StartOfClasses.Count && _lessonMin == 0)
                {
                    Console.WriteLine("___Курс кончился___");
                    _lessonNumber = 0;
                    timer.Dispose();
                }
            }
        }
        /// <summary>
        /// Метод, подсчитывающий количество минут, проведенных пользователями на занятии
        /// </summary>
        static void CollectStatistics()
        {

            var users = _client.GetGuild(Bot.Guild.Id).Users;
            foreach (var user in users)
            {
                if (user.VoiceChannel != null)
                {
                    if (!_statistics.ContainsKey(user.Id))
                    {
                        _statistics.Add(user.Id, 1);
                    }
                    else
                    {
                        _statistics[user.Id]++;
                    }

                }
                else if (user.VoiceChannel == null && !_statistics.ContainsKey(user.Id))
                {
                    _statistics.Add(user.Id, 0);
                }
            }
        }
        /// <summary>
        /// Метод отправляет отчет администратору по окончанию занятия
        /// </summary>
        static void SendSatistics()
        {
            string present = "";
            string absent = "";
            List<ulong> absentUsers = new List<ulong>();

            foreach (var item in _statistics)
            {
                if (item.Value > _lessonDuration / 2)
                {
                    try
                    {
                        if (Users.TryGet(item.Key, out IGuildUser guildUser))
                        {

                            present += guildUser.Mention + ":   " + item.Value + " минут\n";
                        }
                    }
                    catch (Exception ex) { }
 
                }
                else
                {
                    try
                    {
                        if (Users.TryGet(item.Key, out IGuildUser guildUser))
                        {

                            absent += guildUser.Mention + "\n";
                            absentUsers.Add(guildUser.Id);
                        }
                    }
                    catch (Exception ex) { }
                }
            }
            var EmbedBuilderPresent = new EmbedBuilder().WithDescription($"Список присутствовавших: \n{present}");
            Embed embedPresent = EmbedBuilderPresent.Build();

            var EmbedBuilderAbsent = new EmbedBuilder().WithDescription($"Список отсутствовавших: \n{absent}");
            Embed embedAbsent = EmbedBuilderAbsent.Build();

            var admin = _client.GetGuild(Bot.Guild.Id).GetUser(432232509095411743);

            admin.SendMessageAsync(embed: embedPresent);
            admin.SendMessageAsync(embed: embedAbsent);

            User.AddMissedLessons(absentUsers);

            _statistics.Clear();

        }

        /// <summary>
        /// Метод уведомляет пользователей о том, что следующее занятие последнее
        /// </summary>
        static void CloseToEndOfCourseAlert()
        {
            var users = _client.GetGuild(Bot.Guild.Id).Users;

            foreach (var user in users)
            {
                try
                {
                    Send.DirectMessage("Поздравляю, вы дошли до конца курса NowYouSeeSharp! Следующее занятие будет последним)",
                                      $"Дата последнего занятия: {StartOfClasses[_lessonNumber]}", "Желаю удачи!", user.Id);
                }
                catch (Exception ex) { }
            }
        }
        /// <summary>
        /// Метод уведомляет пользователя об отставании от группы
        /// </summary>
        static void BacklogAlert()
        {
            var users = _client.GetGuild(Bot.Guild.Id).Users;
            foreach (var user in users)
            {
                try
                {

                    if (Users.TryGet(user.Id, out User uUser))
                    {
                        if (((uUser.OpenedCourse - 1) * 10 + uUser.OpenedLecture) < ((sections[_lessonNumber] - 1) * 10 + lections[_lessonNumber]))
                        {
                            Send.DirectMessage($"К текущему занятию должна быть открыта {lections[_lessonNumber]} лекция" +
                                               $" {sections[_lessonNumber]} курса. Скорее догоняйте группу!", user.Id);
                        }
                    }

                }
                catch (Exception ex) { }
            }
        }
    }
}
