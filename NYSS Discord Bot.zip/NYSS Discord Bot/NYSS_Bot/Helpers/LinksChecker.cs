﻿using Discord.WebSocket;
using NYSS_Bot.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NYSS_Bot.Helpers
{
    public class LinksChecker
    {
        private static List<string> _prefixesLink = new List<string>()
        {
            "https://",
            "http://",
        };

        /// <summary>
        /// Метод для поиска запрещенных ссылок в принимаемом сообщении
        /// </summary>
        /// <param name="message">Полученное сообщение</param>
        /// <returns>true, если ссылки нет в списке разрешенных</returns>
        public static bool CheckForForbiddenLinks(string message)
        {
            bool isContentForbiddenLink = false;

            foreach (var prefixLink in _prefixesLink)
            {
                if (message.Contains(prefixLink))
                {
                    string[] partsMessageWithLink = message.Split(prefixLink);
                    List<bool> isContentForbiddenLinkInPartMessageWithLink = new List<bool>();

                    for (int i = 1; i < partsMessageWithLink.Length; i++)
                    {
                        isContentForbiddenLinkInPartMessageWithLink.Add(true);

                        foreach (var link in AllowedResources.AllAllowedResourses)
                        {
                            Regex regex = new Regex($"^{link}/");
                            MatchCollection matches = regex.Matches(partsMessageWithLink[i]);
                            if (matches.Count == 0)
                            {
                                isContentForbiddenLinkInPartMessageWithLink[i - 1] &= true;
                            }
                            else
                            {
                                isContentForbiddenLinkInPartMessageWithLink[i - 1] &= false;
                            }
                        }
                    }
                    foreach (var item in isContentForbiddenLinkInPartMessageWithLink)
                    {
                        isContentForbiddenLink |= item;
                    }
                }
            }

            return isContentForbiddenLink;
        }
    }
}
