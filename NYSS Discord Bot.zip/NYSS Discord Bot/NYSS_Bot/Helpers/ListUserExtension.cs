﻿using System.Collections.Generic;
using System.Linq;
using NYSS_Bot.Model;

namespace NYSS_Bot.Helpers
{
    public static class ListUserExtension
    {
        /// <summary>
        /// Метод проверки наличия пользователя по Discord ID в списке разрешенных
        /// </summary>
        /// <param name="data">Исходный список пользователей</param>
        /// <param name="id">id пользователя</param>
        /// <returns></returns>
        public static bool IdExists(this List<User> data, ulong id)
            => data.Where(user => user.Id == id).ToList().Count > 0;

        /// <summary>
        /// Метод получения списка пользователей по заданному значению наличия подписки
        /// </summary>
        /// <param name="data">Исходный список пользователей</param>
        /// <param name="Subscribed">Наличие подписки, по которой будет проодить фильтрация</param>
        /// <returns>Отфильтрованный список</returns>
        public static List<User> GetSubscribedUsers(this List<User> data, bool Subscribed = true)
            => data.Where(user => user.IsSubscribed == Subscribed).ToList();
    }
}
