﻿using System;

namespace NYSS_Bot.Helpers
{
    public static class Logger
    {
        /// <summary>
        /// Выводит лог в консоль
        /// </summary>
        /// <param name="sender">Отправитель сообщения</param>
        /// <param name="message">Текст сообщения</param>
        public static void Push(string sender, string message)
        {
            Console.WriteLine($"{DateTime.Now.ToString("HH:mm:ss")} Sender:     {sender}");
            Console.WriteLine($"         Message:    {message}");
        }
    }
}
