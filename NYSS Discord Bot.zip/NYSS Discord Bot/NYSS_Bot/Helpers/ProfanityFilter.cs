﻿using Discord.Commands;
using NYSS_Bot.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NYSS_Bot.Helpers
{
    public class ProfanityFilter
    {
        /// <summary>
        /// Метод проверяет наличие запрещенных слов и ссылок в сообщении, и при их наличии добавляет пользователю нарушение. 
        /// </summary>
        /// <param name="messageContent">Текст сообщения</param>
        /// <param name="userId">Id автора сообщения</param>
        /// <param name="isAdmin">Является ли автор админом на сервере</param>
        /// <returns>true, если сообщение содержит запрещенный контент, иначе false. false, если автор имеет права администратора</returns>
        public static bool FilterMessage(string messageContent, bool isAdmin)
        {
            bool isWordForbidden = false;

            if (isAdmin)
            {
                return false;
            }
            string[] wordsInMessage = messageContent.Split(' ');

            foreach (var word in wordsInMessage)
            {
                if (ContainsForbiddenWords(word))
                {
                    isWordForbidden = true;
                }
            }
            if (isWordForbidden || LinksChecker.CheckForForbiddenLinks(messageContent))
            {
                return true;
            }

            return false;
        }
        private static bool ContainsForbiddenWords(string word)
        {
            if (_forbiddenWords.Contains(word.ToLower()))
            {
                return true;
            }
            return false;
        }

        private static List<string> _forbiddenWords = new List<string>()
        {
            "плохое слово 1", "плохое слово 2"
        };

        public static List<string> ForbiddenWords { get => _forbiddenWords; private set { } }
    }
}
