﻿using System;
using System.Collections.Generic;
using System.Threading;
namespace NYSS_Bot.Helpers
{
    public class Scheduler
    {
        private static Scheduler _instance;
        public List<Timer> timers = new List<Timer>();
        public static Scheduler Instance => _instance ??= new Scheduler();

        /// <summary>
        /// Вызов задачи в указанное время с указанной периодичностью
        /// </summary>
        /// <param name="firstRun">Время первого запуска task</param>
        /// <param name="interval">Задание периода для запуска task</param>
        /// <param name="task">Выполняемый код</param>
        public void ScheduleTask(DateTime firstRun, TimeSpan interval, Action task)
        {
            DateTime now = DateTime.Now;
            if (now > firstRun)
            {
                firstRun = now.AddMilliseconds(1);
            }

            TimeSpan timeToGo = firstRun - now;
            if (timeToGo.Ticks >= (long)uint.MaxValue * 10000 - 1)
            {
                timeToGo = new TimeSpan((long)uint.MaxValue * 10000 - 1);
                var timer = new Timer(x => ScheduleCheck(firstRun, interval, task), null, timeToGo, interval);
                timers.Add(timer);
            }
            else
            {
                var timer = new Timer(x => task.Invoke(), null, timeToGo, interval);
                timers.Add(timer);
            }
        }
        public void ScheduleCheck(DateTime firstRun, TimeSpan interval, Action task)
        {
            DateTime now = DateTime.Now;
            TimeSpan timeToGo = firstRun - now;

            if (timeToGo.Ticks >= (long)UInt32.MaxValue * 10000 - 1)
            {
                ScheduleTask(firstRun, interval, task);
            }
            else
            {
                var timer = new Timer(x => task.Invoke(), null, timeToGo, interval);
                timers.Add(timer);
            }
        }
    }
}