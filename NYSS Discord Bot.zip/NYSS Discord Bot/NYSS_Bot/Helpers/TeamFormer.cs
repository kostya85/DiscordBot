﻿using NYSS_Bot.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NYSS_Bot.Helpers
{
    static class TeamFormer
    {
        private static Random _random = new Random();

        /// <summary>
        /// Метод возвращает распределение по командам
        /// </summary>
        /// <param name="users"></param>
        /// <returns>Массив (длины 3), где каждый элемент - список юзеров</returns>
        public static List<User>[] GetTeams(List<User> users)
        {
            var teams = new List<User>[3];
            teams[0] = new List<User>();
            teams[1] = new List<User>();
            teams[2] = new List<User>();

            users = users.OrderByDescending(x => x.Level).ToList();

            for (int i = 0; i < users.Count; i++)
            {
                teams[i % 3].Add(users[i]);
            }

            int failedSwaps = 0;
            while (true)
            {
                var newTeams = RandomSwap(teams);
                if (SwapIsSucces(teams, newTeams))
                {
                    failedSwaps = 0;
                    teams = newTeams;
                }
                else
                {
                    failedSwaps++;
                }

                if (failedSwaps == 20)
                {
                    break;
                }
            }

            return teams;
        }

        private static List<User>[] RandomSwap(List<User>[] teams)
        {
            var teamsCopyList = new List<List<User>>();

            teamsCopyList.Add(new List<User>());
            teamsCopyList.Add(new List<User>());
            teamsCopyList.Add(new List<User>());

            for (int i = 0; i < teams.Length; i++)
            {
                teamsCopyList[i] = new List<User>(teams[i]);
            }

            var firstTeam = teamsCopyList[_random.Next(0, 3)];
            teamsCopyList.Remove(firstTeam);

            var secondTeam = teamsCopyList[_random.Next(0, 2)];

            var firstUser = firstTeam[_random.Next(0, firstTeam.Count)];
            firstTeam.Remove(firstUser);

            var secondUser = secondTeam[_random.Next(0, secondTeam.Count)];
            secondTeam.Remove(secondUser);

            firstTeam.Add(secondUser);
            secondTeam.Add(firstUser);

            teamsCopyList.Add(firstTeam);

            return teamsCopyList.ToArray();
        }

        private static double TeamLevel(List<User> team) => team.Sum(x => x.Level);

        private static bool SwapIsSucces(List<User>[] original, List<User>[] changed)
        {
            if (MaxTeamLevelDifference(original) > MaxTeamLevelDifference(changed))
            {
                return true;
            }

            return false;
        }
        private static double MaxTeamLevelDifference(List<User>[] teams)
        {
            return teams.Max(x => TeamLevel(x)) - teams.Min(x => TeamLevel(x));
        }
    }
}