﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace NYSS_Bot.Model
{
    public class AllowedResources
    {
        public static List<string> _allAllowedResourses = new List<string>() { "stackoverflow.com", "nyss.pro", "vk.com/csharp_education_center" };
       
        private static string _pattern = @"^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$";
        private static Regex _rg = new Regex(_pattern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
       
        public static List<string> AllAllowedResourses
        {
            get
            {
                return _allAllowedResourses;
            }
            set
            {
                List<string> list = value;
                List<string> checkedlist = new List<string>();

                for (int i = 0; i < list.Count; i++)
                {
                    if (_rg.IsMatch(list[i]))
                    {
                        checkedlist.Add(list[i]);
                    }
                }
                _allAllowedResourses = checkedlist;
            }
        }

        public static bool AddResourse(string resourse)
        {
            if (_rg.IsMatch(resourse))
            {
                _allAllowedResourses.Add(resourse.Replace("https://", "").Replace("http://", ""));
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool DeleteResourse(int number)
        {
            if (number > 0 && number <= _allAllowedResourses.Count)
            {
                _allAllowedResourses.RemoveAt(number - 1);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
