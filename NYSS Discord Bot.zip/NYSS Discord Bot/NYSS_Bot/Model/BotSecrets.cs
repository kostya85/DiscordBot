﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_Bot.Model
{
    internal class BotSecrets
    {
        public string Token { get; set; }
        public string Api { get; set; }
        public ulong GuildId { get; set; }
        public ulong MainTextChannelId { get; set; }
        public ulong MainVoiceChannelId { get; set; }
        public ulong FirstChannelId { get; set; }
        public ulong SecondChannelId { get; set; }
        public ulong ThirdChannelId { get; set; }
        public string BotPassword { get; set; }
        public string BotEmail { get; set; }
    }
}
