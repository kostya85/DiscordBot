﻿using System.Collections.Generic;

namespace NYSS_Bot.Model
{
    public static class KickReasons
    {
        public static Dictionary<int, string> kickReasons = new Dictionary<int, string>(6)
        {
            {0, "Систематическое нарушение установленных правил"},
            {1, "Пропуск более N занятий"},
            {2, "Истечение срока проведения курса"},
            {3, "Отставание от общей группы на N и более лекций"},
            {4, "Изменение списка авторизованных пользователей"},
            {5, "По заданному расписанию"}
        };

        public static string ViolatedRules { get => kickReasons[0]; }
        public static string MissedLessons { get => kickReasons[1]; }
        public static string EndOfCourse { get => kickReasons[2]; }
        public static string LaggedLectures { get => kickReasons[3]; }
        public static string ChangeUserList { get => kickReasons[4]; }
        public static string BySchedule { get => kickReasons[5]; }

        public static string GetAllValues()
        {
            string res = "";

            foreach (var item in kickReasons)
            {
                res += $"{item.Key} - {item.Value}\n";
            }

            return res;
        }

        public static void SetNumberMissedClasses(int num)
        {
            if (num < 0)
            {
                num = 0;
            }

            kickReasons[1] = $"Пропуск более {num} занятий";
        }

        public static void SetNumberLaggedLectures(int num)
        {
            if (num < 0)
            {
                num = 0;
            }

            kickReasons[3] = $"Отставание от общей группы на {num} и более лекций";
        }
    }
}
