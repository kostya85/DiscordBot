﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_Bot.Model
{
    /// <summary>
    /// Класс необходим для общения с api сервера (представляет ссылку в json формате и отправляет на сервер)
    /// </summary>
    class Link
    {
        public string Mail { get; set; }
        public string InviteLink { get; set; }
        public string Code { get; set; }
        public Link(string mail, string link, string code)
        {
            Mail = mail;
            InviteLink = link;
            Code = code;
        } 
    }
}
