﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_Bot.Model
{
    /// <summary>
    /// Классы - модели для десериализации json строки с расписанием занятий с портала
    /// </summary>
    public class ScheduleResponseModel
    {
        public List<Lesson> Schedule { get; set; }
    }
    public class Lesson
    {
        public string Lection { get; set; }
        public DateTime Date { get; set; }
    }
}
