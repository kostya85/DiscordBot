﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using NYSS_Bot.Helpers.Distribution;
using System.Threading.Tasks;
using Discord;

namespace NYSS_Bot.Model
{
    public class User
    {
        public static List<User> userList = new List<User>();
        public static List<User> unauthorized = new List<User>();

        private ulong _id;
        private string _name;
        private string _surname;
        private string _mail;
        private bool _isSubscribed;
        private string _link;

        [NonSerialized]
        private CustomKickTimer kickTimer;

        public void StartKickTimer()
        {
            kickTimer = new CustomKickTimer(this);
        }

        /// <summary>
        /// Disposes timer as well
        /// </summary>
        public void StopKickTimer()
        {
            kickTimer.Stop();
            kickTimer = null;
        }

        private string _lastOpenedLecture;

        public double Level { get; set; }
        public int TotalExerciseCount { get; set; }
        public int ViolatedRulesCount { get; set; }
        public int MissedLessonsCount { get; set; }
        public int OpenedLecture { get; set; }
        public int OpenedCourse { get; set; }

        public string LastOpenedLecture
        {
            get => _lastOpenedLecture;
            set
            {
                var courseToLecture = value.Split("_");
                OpenedCourse = Convert.ToInt32(courseToLecture[0]);
                OpenedLecture = Convert.ToInt32(courseToLecture[1]);
                _lastOpenedLecture = value;
            }
        }

        public string Link { get => _link; set => _link = value; }

        public bool IsSubscribed
        {
            get => _isSubscribed;
            set => _isSubscribed = value;
        }
        public ulong Id
        {
            get => _id;
            set => _id = value;
        }
        public string Name
        {
            get => _name;
            set => _name = value;
        }
        public string Surname
        {
            get => _surname;
            set => _surname = value;
        }
        public string Mail
        {
            get => _mail;
            set => _mail = value;
        }

        /// <summary>
        /// Удаляет пользователя с сервера.
        /// Не сработает, если юзера нет на сервере
        /// </summary>
        /// <returns></returns>
        public async Task AutoKickAsync()
        {
            Users.TryGet(_id, out IGuildUser user);

            if (user != null)
            {
                await user.SendMessageAsync("Вы не прошли аутентификацию");
                await user.KickAsync();
            }
        }

        public static void AddMissedLessons(List<ulong> ids)
        {
            for (int i = 0; i < ids.Count; i++)
            {
                foreach (var user in userList)
                {
                    if (ids[i] == user.Id)
                    {
                        user.MissedLessonsCount++;
                    }
                }
            }
        }
    }
}
