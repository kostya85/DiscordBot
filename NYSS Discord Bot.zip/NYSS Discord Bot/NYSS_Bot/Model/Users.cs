﻿using Discord;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NYSS_Bot.Model
{
    /// <summary>
    /// Статический класс для хранения и учета авторизованных пользователей
    /// </summary>
    public static class Users
    {
        private static Dictionary<ulong, User> _idToUsers;
        private static Dictionary<ulong, IGuildUser> _idToGuildUsers;

        public static List<User> Unauthorized { get; }

        public static Predicate<ulong> IsAdmin { get; }

        public static Predicate<ulong> IsAuthorized { get; }
        public static Predicate<ulong> IsUnauthorized { get; }

        public static IReadOnlyCollection<IGuildUser> All => Bot.Guild.Users;

        static Users()
        {
            _idToGuildUsers = new Dictionary<ulong, IGuildUser>();
            _idToUsers = new Dictionary<ulong, User>();
            Unauthorized = new List<User>();

            IsAdmin = id =>
            {
                var adminRole = Bot.Guild.Roles.FirstOrDefault(x => x.Name == "administrator");
                var admins = Bot.Guild.Users
                    .Where(x => x.Guild.Roles.Contains(adminRole))
                    .Select(usr => usr.Id);
                return admins.Contains(id);
            };

            IsAuthorized = id => _idToUsers.ContainsKey(id);
            IsUnauthorized = id => Unauthorized.Select(usr => usr.Id).Contains(id);
        }

        /// <summary>
        /// Добавляет пользователей в словари.
        /// В случае, если какой-то пользователь уже существует, то он заменяется на новый.
        /// </summary>
        /// <param name="users">Словарь</param>
        public static void AddAll(Dictionary<User, IGuildUser> users)
        {
            foreach (var (user, guildUser) in users)
            {
                Add(user, guildUser);
            }
        }

        /// <summary>
        /// Добавляет пользователя в словари
        /// В случае, если пользователь уже существует, он заменяется на новый.
        /// </summary>
        /// <param name="user">Представление пользователя в системе</param>
        /// <param name="guildUser">Представление пользователя в дискорде</param>
        public static void Add(User user, IGuildUser guildUser)
        {
            if (_idToUsers.ContainsKey(user.Id))
            {
                _idToUsers.Remove(user.Id);
            }
            if (_idToUsers.ContainsKey(user.Id))
            {
                _idToUsers.Remove(user.Id);
            }

            _idToGuildUsers.Add(user.Id, guildUser);
            _idToUsers.Add(user.Id, user);
        }

        /// <summary>
        /// Метод для получения объекта <c>User</c> по id пользователя
        /// </summary>
        /// <param name="id">id пользователя</param>
        /// <param name="user">Выходящий параметр - пользователь</param>
        /// <returns><c>true</c> если пользователь с таким id Существует, иначе - <c>false</c></returns>
        public static bool TryGet(ulong id, out User user)
        {
            bool authorizedIsFound = _idToUsers.TryGetValue(id, out user);

            if (!authorizedIsFound)
            {
                var unauthorized = Unauthorized.Find(usr => usr.Id == id);

                if (unauthorized != null)
                {
                    user = unauthorized;
                    return true;
                }

                return false;
            }

            return true;
        }

        /// <summary>
        /// Метод для получения объекта <c>GuildUser</c> по id пользователя
        /// </summary>
        /// <param name="id">id пользователя</param>
        /// <param name="guildUser">Выходящий параметр - пользователь</param>
        /// <returns><c>true</c> если пользователь с таким id Существует, иначе - <c>false</c></returns>
        public static bool TryGet(ulong id, out IGuildUser guildUser)
        {
            bool authorizedIsFound = _idToGuildUsers.TryGetValue(id, out guildUser);

            if (!authorizedIsFound)
            {
                var unauthorized = Unauthorized.Find(usr => usr.Id == id);

                if (unauthorized != null)
                {
                    guildUser = Bot.Guild.Users.First(gu => gu.Id == id);
                    return true;
                }

                return false;
            }

            return true;
        }

        /// <summary>
        /// Метод для получения объекта <c>GuildUser</c> по объекту <c>User</c>
        /// </summary>
        /// <param name="user">Входной параметр</param>
        /// <param name="guildUser">Выходной параметр</param>
        /// <returns><c>true</c> если пользователь существует, иначе - <c>false</c></returns>
        public static bool TryGet(User user, out IGuildUser guildUser)
        {
            return TryGet(user.Id, out guildUser);
        }

        /// <summary>
        /// Метод для получения объекта <c>User</c> по объекту <c>GuildUser</c>
        /// </summary>
        /// <param name="guildUser">Входной параметр</param>
        /// <param name="user">Выходной параметр</param>
        /// <returns><c>true</c> если пользователь существует, иначе - <c>false</c></returns>
        public static bool TryGet(IGuildUser guildUser, out User user)
        {
            return TryGet(guildUser.Id, out user);
        }

        /// <summary>
        /// Применяет действие action дял каждого пользователя, удовлетворяющего условию predicate
        /// </summary>
        /// <param name="predicate">Условие</param>
        /// <param name="action">Действие</param>
        public static void ForEachWhere(Predicate<ulong> predicate, Action<ulong> action)
        {
            foreach (var user in Bot.Guild.Users)
            {
                if (predicate(user.Id))
                {
                    action(user.Id);
                }
            }
        }

        /// <summary>
        /// Удаляет пользователя, если он есть
        /// </summary>
        /// <param name="userId">id пользователя</param>
        public static void RemoveIfExists(ulong userId)
        {
            _idToUsers.Remove(userId);
            _idToGuildUsers.Remove(userId);
        }
    }
}