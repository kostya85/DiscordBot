﻿
namespace NYSS_Bot.Model.Validation
{
    /// <summary>
    /// Interface <c>IRule</c> represents a rule that users must follow
    /// </summary>
    internal interface IRule
    {
        /// <summary>
        /// Method for checking if the user is breaking a rule
        /// </summary>
        /// <param name="user">User</param>
        /// <param name="kickReason">Why is the user breaking a rule</param>
        /// <returns><c>true</c> if the user follows the rule, otherwise <c>false</c>
        /// </returns>
        public bool CheckFor(User user, out string kickReason);
    }
}