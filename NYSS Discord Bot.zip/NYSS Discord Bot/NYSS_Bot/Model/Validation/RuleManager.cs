﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace NYSS_Bot.Model.Validation
{
    /// <summary>
    /// Class <c>RuleManager</c> manages rules
    /// </summary>
    internal class RuleManager
    {
        private List<IRule> _currentRules;

        /// <summary>
        /// Returns a list of rules contained in assembly
        /// </summary>
        public List<IRule> CurrentRules
        {
            get => _currentRules;
        }

        /// <summary>
        /// This constructor initializes a <c>CurrentRules</c> property
        /// </summary>
        public RuleManager()
        {
            _currentRules = Assembly.GetExecutingAssembly()
                .GetTypes()
                .Where(type => typeof(IRule).IsAssignableFrom(type) && type != typeof(IRule))
                .Select(iRule => (IRule) Activator.CreateInstance(iRule))
                .ToList();
        }
    }
}
