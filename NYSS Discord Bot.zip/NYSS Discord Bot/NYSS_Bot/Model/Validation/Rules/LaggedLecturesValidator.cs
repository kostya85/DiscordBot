﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace NYSS_Bot.Model.Validation.Rules
{
    class LaggedLecturesValidator : IRule
    {
        private static int _acceptableLag = 3;
        private static int _requiredLecture = 0;
        private static List<string> _listAllLectionFromSchedule = new List<string>();
        private static List<Lesson> _gotSchedule = new List<Lesson>();
        static LaggedLecturesValidator()
        {
            _gotSchedule = NyssApi.GetScheduleAsync().Result;
            _listAllLectionFromSchedule = GetListOfLection(_gotSchedule);
            _requiredLecture = GetRequiredLecture(_gotSchedule);
        }

        public bool CheckFor(User user, out string kickReason)
        {
            kickReason = "";
            if (_requiredLecture - GetSumLectionsByStringFormatLection(user.LastOpenedLecture) >= _acceptableLag)
            {
                KickReasons.SetNumberLaggedLectures(_acceptableLag);
                kickReason = KickReasons.LaggedLectures;
                return false;
            }
            else
            {
                return true;
            }
        }

        public static void Test()
        {
            Console.WriteLine(GetRequiredLecture(_gotSchedule));
        }

        /// <summary>
        /// Метод для получения количества лекций, которые должны быть открыты к текущему моменту.
        /// Если текущая дата более поздняя, либо равная, дате последнего занятия, то необходимо открыть все лекции.
        /// </summary>
        /// <param name="gotSchedule">Список объектов CourseSchedule, содежащий расписание.</param>
        /// <returns>Число лекций.</returns>
        private static int GetRequiredLecture(List<Lesson> gotSchedule)
        {
            long timeUntilNextLection = DateTime.MaxValue.Ticks;
            string nearestLection = "";
            int curIndexSchduleLection = gotSchedule.Count - 1;
            string lastLection = gotSchedule[curIndexSchduleLection].Lection;

            for (int i = 0; i < gotSchedule.Count - 1; i++)
            {
                long timeUntilLection = (DateTime.Now - gotSchedule[i].Date).Ticks;

                if (timeUntilLection < 0)
                {
                    curIndexSchduleLection = i - 1;
                    break;
                }
                else if (timeUntilLection < timeUntilNextLection)
                {
                    timeUntilNextLection = timeUntilLection;
                    nearestLection = gotSchedule[i].Lection;
                    curIndexSchduleLection = i;
                }
            }

            nearestLection = GetNearestLection(nearestLection, curIndexSchduleLection, gotSchedule);

            if (DateTime.Now >= gotSchedule[gotSchedule.Count - 1].Date)
            {
                lastLection = GetNearestLection(lastLection, gotSchedule.Count - 1, gotSchedule);
                return GetSumLectionsByStringFormatLection(lastLection);
            }

            string requiredLection = SubtractLectureWithNum(nearestLection, _acceptableLag);
            int result = GetSumLectionsByStringFormatLection(requiredLection);

            return result;
        }

        /// <summary>
        /// Метод для проверки, что переданное занятие является лекцией, а не другим занятием (олимпиада или тест) 
        /// и, если это так, получения этой лекции, 
        /// если переданное занятие не является лекцией, проверяется ближайшее прошедшее занятие,
        /// если лекций в расписании нет, то вернет "0_0".
        /// </summary>
        /// <param name="lection">Строковое представление занятия;</param>
        /// <param name="curIndexSchdule">Индекс от которого будем искать ближайщие занятия-лекции;</param>
        /// <param name="gotSchedule">Список объектов CourseSchedule, содежащий расписание.</param>
        /// <returns>Лекция в строковом формате (например, 1_5).</returns>
        private static string GetNearestLection(string lection, int curIndexSchdule, List<Lesson> gotSchedule)
        {
            while (true)
            {
                Regex regex = new Regex($"[0-9]+_[0-9]+");
                MatchCollection matches = regex.Matches(lection);

                if (matches.Count != 0)
                {
                    if (curIndexSchdule < 0)
                    {
                        lection = "0_0";
                    }
                    break;
                }
                else
                {
                    if (curIndexSchdule > 0)
                    {
                        curIndexSchdule -= 1;
                        lection = gotSchedule[curIndexSchdule].Lection;
                    }
                    else
                    {
                        lection = "0_0";
                    }
                }
            }

            return lection;
        }

        /// <summary>
        /// Метод для вычитания из лекции числа. 
        /// </summary>
        /// <param name="curLection">Строковое представление текущей лекции;</param>
        /// <param name="num">Число лекций, на которое можно отстать.</param>
        /// <returns>Лекция в строковом формате (например, 1_5).</returns>
        private static string SubtractLectureWithNum(string curLection, int num)
        {
            string[] parsedCurLection = curLection.Split("_");
            int numCurCourse = Convert.ToInt32(parsedCurLection[0]);
            int numCurLection = Convert.ToInt32(parsedCurLection[1]);

            do
            {
                if ((numCurLection - num) > 0)
                {
                    numCurLection -= num;
                    break;
                }
                else if ((numCurLection - num) == 0)
                {
                    numCurLection = 9;
                    numCurCourse--;
                    break;
                }
                else if ((numCurLection - num) < 0)
                {
                    num -= numCurLection;
                    numCurLection = 9;
                    numCurCourse--;
                }
            } while (num > 0);

            return numCurCourse > 0 ? $"{numCurCourse}_{numCurLection}" : $"{0}_{0}";
        }

        /// <summary>
        /// Метод для вычисления числа пройденных лекций по переданному строковому представлению лекции,
        /// подразумевается, что курсы могут содержат произвольное число лекций.
        /// </summary>
        /// <param name="lection">Строковое представление лекции.</param>
        /// <returns>Число лекций.</returns>
        private static int GetSumLectionsByStringFormatLection(string lection)
        {
            int res = 0;
            Dictionary<int, int> numberOfLectionInCource = new Dictionary<int, int>();

            foreach (var item in _listAllLectionFromSchedule)
            {
                string[] parsedItem = item.Split("_");
                int numCourse = Convert.ToInt32(parsedItem[0]);
                int numLection = Convert.ToInt32(parsedItem[1]);
                if (!numberOfLectionInCource.ContainsKey(numCourse))
                {
                    numberOfLectionInCource.Add(numCourse, numLection);
                }
                else if (numberOfLectionInCource[numCourse] < numLection)
                {
                    numberOfLectionInCource[numCourse] = numLection;
                }
            }

            string[] parsedCurLection = lection.Split("_");
            int numCurCourse = Convert.ToInt32(parsedCurLection[0]);
            int numCurLection = Convert.ToInt32(parsedCurLection[1]);

            foreach (var item in numberOfLectionInCource)
            {
                if (item.Key < numCurCourse)
                {
                    res += item.Value;
                }
                else if (item.Key == numCurCourse)
                {
                    res += numCurLection;
                }
                else
                {
                    break;
                }
            }

            return res;
        }

        /// <summary>
        /// Метод для получения списка лекций из расписания,  
        /// (в общем случае расписание может содержать не только лекции, но тесты и олимпиады).
        /// </summary>
        /// <param name="gotSchedule">Список объектов CourseSchedule, содежащий расписание.</param>
        /// <returns>Список лекций, представленных в строковом формате (например, 1_5).</returns>
        private static List<string> GetListOfLection(List<Lesson> gotSchedule)
        {
            List<string> listOnlyLection = new List<string>();
            Regex regex = new Regex($"[0-9]+_[0-9]+");

            foreach (var item in gotSchedule)
            {
                MatchCollection matches = regex.Matches(item.Lection);
                if (matches.Count != 0)
                {
                    listOnlyLection.Add(item.Lection);
                }
            }

            listOnlyLection.Sort();

            return listOnlyLection;
        }
    }
}
