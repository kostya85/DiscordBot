﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_Bot.Model.Validation.Rules
{
    class MissedLessonsValidator : IRule
    {
        private int _acceptableNumberOfMissedLessons = 1;
        public bool CheckFor(User user, out string kickReason)
        {
            kickReason = "";
            if (user.MissedLessonsCount > _acceptableNumberOfMissedLessons)
            {
                KickReasons.SetNumberMissedClasses(_acceptableNumberOfMissedLessons);
                kickReason = KickReasons.MissedLessons;
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
