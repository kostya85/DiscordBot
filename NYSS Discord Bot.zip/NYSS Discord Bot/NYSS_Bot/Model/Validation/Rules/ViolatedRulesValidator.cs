﻿using System;
using System.Collections.Generic;
using System.Text;


namespace NYSS_Bot.Model.Validation.Rules
{
    class ViolatedRulesValidator : IRule
    {
        private int _acceptableNumberOfViolations = 1;
        public bool CheckFor(User user, out string kickReason)
        {
            kickReason = "";
            if (user.ViolatedRulesCount > _acceptableNumberOfViolations)
            {
                kickReason = KickReasons.ViolatedRules;
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
