﻿using Microsoft.Extensions.Configuration;
using NYSS_Bot.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace NYSS_Bot
{
    class Program
    {
        private static string _token;

        static void Main(string[] args)
        {
            Initialize();

            var config = new ConfigurationBuilder().AddUserSecrets<BotSecrets>().Build();
            config.Providers.First().TryGet("Token", out _token);

            if (_token != null)
            {
                new Bot(_token).MainAsync().GetAwaiter().GetResult();
            }
            else
            {
                throw new Exception("Токен не задан");
            }
        }
        static void Initialize()
        {
            string path = Path.GetFullPath(@"..\..\..\TestUsers.json");
            if (File.Exists(path))
            {
                User.userList = JsonSerializer.Deserialize<List<User>>(File.ReadAllText(path));
            }
        }
    }
}

