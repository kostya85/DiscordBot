﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NYSS_Bot.API;
using System.Collections.Generic;
using System.Linq;

namespace NYSS_BotTests.InviteTests
{
    [TestClass()]
    class InvitationTests
    {
        [TestMethod()]
        public void InviteUrlNotEmpty()
        {
            foreach (var item in DiscordApi.GetInviteUrls(5))
            {
                Assert.AreNotEqual(item, "");
            }
        }

        [TestMethod()]
        public void InvitesAreUnique()
        {
            var list = new List<string>();
            foreach (var item in DiscordApi.GetInviteUrls(5))
            {
                list.Add(item);
            }

            foreach (var url in list)
            {
                int uniqueUrlCount = list.Where(x => x == url).ToArray().Length;
                Assert.AreEqual(uniqueUrlCount, 1);
            }
        }
    }
}
