﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_BotTests
{
    internal class BotTestsSecrets
    {
        public string Token { get; set; }
        public string Api { get; set; }
        public ulong GuildId { get; set; }
        public string ChannelId { get; set; }
        public string BotPassword { get; set; }
        public string BotEmail { get; set; }
    }
}
