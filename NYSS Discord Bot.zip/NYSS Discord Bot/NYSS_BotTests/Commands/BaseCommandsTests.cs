﻿using Discord;
using Discord.WebSocket;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NYSS_Bot;
using NYSS_Bot.Model;
using NYSS_Bot.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using NYSS_BotTests.Model;
using System.Threading;

namespace NYSS_BotTests.Commands
{
    [TestClass]
    public class BaseCommandsTests
    {
        [TestMethod]
        public async Task AllUsersReceivedSendedMessages()
        {

            List<ulong> actualUserIds = new List<ulong>();
            List<ulong> expectedUserIds = new List<ulong>();

            string _token;
            string temp_guildId;

            var config = new ConfigurationBuilder().AddUserSecrets<BotTestsSecrets>().Build();
            config.Providers.First().TryGet("Token", out _token);

            config.Providers.First().TryGet("GuildId", out temp_guildId);
            ulong guildId = ulong.Parse(temp_guildId);
            Bot bot = new Bot(_token);

            bot.MainAsync();
            FieldInfo fieldInfo = typeof(Bot).GetField("_client", BindingFlags.Instance | BindingFlags.NonPublic);
            DiscordSocketClient _client = (DiscordSocketClient)fieldInfo.GetValue(bot);
            _client.Ready += async () =>
            {
                foreach (var user in _client.GetGuild(guildId).Users)
                {
                    if (!user.IsBot)
                    {
                        
                     //   await BaseCommands.MessageForUser(user, user.Id.ToString());
                        actualUserIds.Add(user.Id);
                    }
                }
                await Task.CompletedTask;
            };

            _client.MessageReceived += async (message) =>
            {
                var users = message.Channel.GetUsersAsync();
                await foreach (var item in users)
                {
                    foreach (IUser user in item)
                    {
                        if (!user.IsBot)
                        {
                            string mesContent = message.Embeds.First().Description;
                            if (mesContent == user.Id.ToString())
                            {
                                expectedUserIds.Add(user.Id);
                            }
                        }
                    }
                }

                await Task.CompletedTask;

            };

            await _client.LoginAsync(TokenType.Bot, _token);
            await _client.StartAsync();
            await Task.Delay(3500);
            CollectionAssert.AreEqual(expectedUserIds, actualUserIds);
        }
    }
}
