﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;
using System.Text;

namespace NYSS_Bot.Commands.Tests
{

    [TestClass()]
    public class UserCommandsTests
    {
        /// <summary>
        /// Токен для авторизации бота
        /// </summary>
        private string Token = "";

        #region CustomStream Class
        /// <summary>
        /// Класс, реализующий перехват консольного потока вывода
        /// </summary>
        private class CustomStream
        {
            private MemoryStream ms;
            private StreamWriter sw;
            private TextWriter defaultWriter;

            /// <summary>
            /// Поле, хранящее перехваченные данные консольного потка
            /// </summary>
            public string Text { get => ms != null ? Encoding.UTF8.GetString(ms.ToArray()) : string.Empty; }
            
            public CustomStream()
            {
                defaultWriter = Console.Out;
                ms = new MemoryStream();
                sw = new StreamWriter(ms, Encoding.UTF8);
                sw.AutoFlush = true;
            }

            /// <summary>
            /// Захват консольного потока
            /// </summary>
            public void Capture( )
            {
                ms.SetLength(0);
                Console.SetOut(sw);
            }

            /// <summary>
            /// Освобождение консольного потока
            /// </summary>
            public void Dispose()
            {
                Console.SetOut(defaultWriter);
                sw.Close();
            }
        }
        #endregion
    }
}