﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NYSS_Bot.Helpers.Distribution;
using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_BotTests.Helpers
{
    [TestClass()]
    class ContactDataValidatorTests
    {
        /// <summary>
        /// Проверяет правильно ли метод проверяет корректный адрес
        /// </summary>
        [TestMethod()]
        public void Accept_valid_email()
        {
            string mail = "naMe.lAstN11ame@mail.ru";
            Assert.IsTrue(ContactDataValidator.IsEmailValid(mail));
        }
        [TestMethod()]
        public void Accept_valid_email2()
        {
            string mail = "ok_ok@mail.ru";
            Assert.IsTrue(ContactDataValidator.IsEmailValid(mail));
        }
        /// <summary>
        /// Проверяет правильно ли метод проверяет неправильный адрес
        /// </summary>
        [TestMethod()]
        public void Decline_invalid_email()
        {
            string mail = "naMe.lAstN11ame@mail.r";
            Assert.IsFalse(ContactDataValidator.IsEmailValid(mail));
        }
        [TestMethod()]
        public void Decline_invalid_email2()
        {
            string mail = "naMelAstN11ame@mail";
            Assert.IsFalse(ContactDataValidator.IsEmailValid(mail));
        }
        [TestMethod()]
        public void Decline_invalid_email3()
        {
            string mail = "naMe.lAstN11ame@mail.ru@gmail.com";
            Assert.IsFalse(ContactDataValidator.IsEmailValid(mail));
        }
        [TestMethod()]
        public void Decline_invalid_email4()
        {
            string mail = "not#Ok@gmail.com";
            Assert.IsFalse(ContactDataValidator.IsEmailValid(mail));
        }
    }
}
