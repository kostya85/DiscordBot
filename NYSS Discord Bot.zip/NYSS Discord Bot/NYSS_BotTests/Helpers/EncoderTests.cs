﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using NYSS_Bot.Helpers;
namespace NYSS_BotTests.Helpers
{
    [TestClass()]
    public class EncoderTests
    {
        /// <summary>
        /// Метод проверят, что длина сгенерированного ключа = 6
        /// </summary>
        [TestMethod()]
        public void Get_key_length_true()
        {
            Assert.AreEqual(6, NYSS_Bot.Helpers.Encoder.GenerateKey(6).Length);
        }
        /// <summary>
        /// Метод генерирует код-приглашение и проверяет, чтобы индекс вхождения ссылки в него был равен  3
        /// </summary>
        [TestMethod()]
        public void Encode_true()
        {
            for(int i = 0; i < 200; i++)
            {
                string link = "some link #"+i;
                Assert.AreEqual(NYSS_Bot.Helpers.Encoder.Encode(link).Length, link.Length+6);
                Assert.AreEqual(3, NYSS_Bot.Helpers.Encoder.Encode(link).IndexOf(link));
            }
        }
        /// <summary>
        /// Метод проверяет равенство между исходной ссылкой и ссылкой, которая была зашифрована и дешифрована
        /// </summary>
        [TestMethod()]
        public void Decode_true()
        {
            string[] codes = new string[100];
            string[] links = new string[100];
            for(int i = 0; i < 100; i++)
            {
                codes[i] = NYSS_Bot.Helpers.Encoder.Encode("Some link");
                links[i] = NYSS_Bot.Helpers.Encoder.Decode(codes[i]);
                Assert.AreEqual("Some link", links[i]);
            }
        }
    }
}
