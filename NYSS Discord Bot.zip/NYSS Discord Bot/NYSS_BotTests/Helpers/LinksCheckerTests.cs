﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using NYSS_Bot.Helpers;
using NYSS_Bot.Model;

namespace NYSS_BotTests.Helpers
{
    [TestClass()]
    public class LinksCheckerTests
    {
        /// <summary>
        /// Метод проверяет, что CheckForForbiddenLinks() возвращает true, 
        /// если список разрешенных ресурсов AllowedResources пуст.
        /// </summary>
        [TestMethod()]
        public void CheckMessageWhenListOfAllowedResourecesIsEmpty()
        {
            string message = "Link to answer: https://stackoverflow.com/questions/47769547/how-do-i-what/47786315";
            AllowedResources.AllAllowedResourses.Clear();
            Assert.IsTrue(LinksChecker.CheckForForbiddenLinks(message));
        }

        /// <summary>
        /// Метод проверяет, что CheckForForbiddenLinks() возвращает false, 
        /// если сообщение содержит ссылку на ресурс, который есть в списке разрешенных.
        /// </summary>
        [TestMethod()]
        public void CheckMessageThatContainsAllowedLink()
        {
            string message = "Link to answer: https://stackoverflow.com/questions/47769547/how-do-i-what/47786315 ";
            AllowedResources.AddResourse($"stackoverflow.com");
            Assert.IsFalse(LinksChecker.CheckForForbiddenLinks(message));
            AllowedResources.AllAllowedResourses.Remove($"stackoverflow.com");
        }

        /// <summary>
        /// Метод проверяет, что CheckForForbiddenLinks() возвращает true, 
        /// если сообщение содержит ссылку на ресурс, которого нет в списке разрешенных.
        /// При этом в списке разрешенных один ресурс.
        /// </summary>
        [TestMethod()]
        public void CheckMessageThatContainsForbiddenLinkWhenListOfAllowedResourecesContainsOneResource()
        {
            string message = "Link to article: https://ru.wikipedia.org/wiki/%D0%A0%D0%B5%D0%B3%D1";
            AllowedResources.AddResourse($"stackoverflow.com");
            Assert.IsTrue(LinksChecker.CheckForForbiddenLinks(message));
            AllowedResources.AllAllowedResourses.Remove($"stackoverflow.com");
        }

        /// <summary>
        /// Метод проверяет, что CheckForForbiddenLinks() возвращает false, 
        /// если сообщение содержит ссылку на ресурс, который есть в списке разрешенных.
        /// При этом в списке разрешенных два ресурса.
        /// </summary>
        [TestMethod()]
        public void CheckMessageThatContainsForbiddenLinkWhenListOfAllowedResourecesContainsTwoResources()
        {
            string message = "Link to answer: https://stackoverflow.com/questions/47769547/how-do-i-what/47786315";
            AllowedResources.AddResourse($"stackoverflow.com");
            AllowedResources.AddResourse($"nyss.pro");
            Assert.IsFalse(LinksChecker.CheckForForbiddenLinks(message));
            AllowedResources.AllAllowedResourses.Remove($"stackoverflow.com");
            AllowedResources.AllAllowedResourses.Remove($"nyss.pro");
        }

        /// <summary>
        /// Метод проверяет, что CheckForForbiddenLinks() возвращает true, 
        /// если сообщение содержит ссылки на ресурсы, один из которых есть в списке разрешенных, а второй - нет.
        /// </summary>
        [TestMethod()]
        public void CheckMessageThatContainsAllowedAndForbiddenLinks()
        {
            string message = "Link to answer: https://stackoverflow.com/questions/47769547/how-do-i-what/47786315 " +
                "Link to article: https://ru.wikipedia.org/wiki/%D0%A0%D0%B5%D0%B3%D1";
            AllowedResources.AddResourse($"stackoverflow.com");
            Assert.IsTrue(LinksChecker.CheckForForbiddenLinks(message));
            AllowedResources.AllAllowedResourses.Remove($"stackoverflow.com");
        }

        /// <summary>
        /// Метод проверяет, что CheckForForbiddenLinks() возвращает false, 
        /// если сообщение не содержит ссылки.
        /// </summary>
        [TestMethod()]
        public void CheckMessageWithoutLinks()
        {
            string message = "Link to answer: stackoverflow.com/questions/47769547/how-do-i-what/47786315 " +
                "Link to article: ru.wikipedia.org/wiki/%D0%A0%D0%B5%D0%B3%D1";
            AllowedResources.AddResourse($"stackoverflow.com");
            Assert.IsFalse(LinksChecker.CheckForForbiddenLinks(message));
            AllowedResources.AllAllowedResourses.Remove($"stackoverflow.com");
        }

    }
}
