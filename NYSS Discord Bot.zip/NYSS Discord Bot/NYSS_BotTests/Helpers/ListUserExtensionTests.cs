﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NYSS_Bot.Helpers;
using System;
using System.Collections.Generic;
using System.Text;
using NYSS_Bot.Model;

namespace NYSS_Bot.Helpers.Tests
{
    [TestClass()]
    public class ListUserExtensionTests
    {
        [TestMethod()]
        public void GetSubscribedUsersTest_34_of_100_true()
        {
            // arange
            List<User> users = new List<User>();
            List<User> expected = new List<User>();
            List<User> actual;
            for (int i = 0; i < 100; i++)
            {
                User user = new User() { IsSubscribed = i % 3 == 0 };
                users.Add(user);
                if (i % 3 == 0)
                {
                    expected.Add(user);
                }
            }

            // act
            actual = users.GetSubscribedUsers(true);

            // assert
            CollectionAssert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void GetSubscribedUsersTest_0_of_100_true()
        {
            // arange
            List<User> users = new List<User>();
            List<User> expected = new List<User>();
            List<User> actual;
            for (int i = 0; i < 100; i++)
            {
                User user = new User() { IsSubscribed = false };
                users.Add(user);
            }

            // act
            actual = users.GetSubscribedUsers(true);

            // assert
            CollectionAssert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void IsExistIdTest_0_of_100()
        {
            // arange
            List<User> users = new List<User>();
            bool actual;
            for (uint i = 0; i < 100; i++)
            {
                User user = new User() { Id = i };
                users.Add(user);
            }

            // act
            actual = users.IdExists(500);

            // assert
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void IsExistIdTest_1_of_100()
        {
            // arange
            List<User> users = new List<User>();
            bool actual;
            for (uint i = 0; i < 100; i++)
            {
                User user = new User() { Id = i };
                users.Add(user);
            }

            // act
            actual = users.IdExists(50);

            // assert
            Assert.IsTrue(actual);
        }
    }
}