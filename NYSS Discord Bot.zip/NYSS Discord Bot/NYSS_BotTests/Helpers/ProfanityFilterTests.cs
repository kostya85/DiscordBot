﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace NYSS_Bot.Helpers.Tests
{
    [TestClass()]
    public class ProfanityFilterTests
    {
        static Random rnd = new Random();
        [TestMethod()]
        public void FilterMessageTest_forbiddenWord_notAdmin_true()
        {
            string word = ProfanityFilter.ForbiddenWords[rnd.Next(0, ProfanityFilter.ForbiddenWords.Count)];
            Assert.IsTrue(ProfanityFilter.FilterMessage(word, false));            
        }
        [TestMethod()]
        public void FilterMessageTest_NotForbiddenWords_notAdmin_false()
        {
            string word = "Какой чудесный день! Какой чудесный пень! Какой чудесный я! И песенка моя!";
            Assert.IsFalse(ProfanityFilter.FilterMessage(word, false));
        }

        [TestMethod()]
        public void FilterMessageTest_forbiddenWord_Admin_false()
        {
            string word = ProfanityFilter.ForbiddenWords[rnd.Next(0, ProfanityFilter.ForbiddenWords.Count)];
            Assert.IsFalse(ProfanityFilter.FilterMessage(word, true));
        }

        [TestMethod()]
        public void FilterMessageTest_NotForbiddenWords_Admin_false()
        {
            string word = "Какой чудесный день! Какой чудесный пень! Какой чудесный я! И песенка моя!";
            Assert.IsFalse(ProfanityFilter.FilterMessage(word, true));
        }
    }
}