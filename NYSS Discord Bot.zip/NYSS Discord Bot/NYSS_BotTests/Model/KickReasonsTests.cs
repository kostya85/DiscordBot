using Microsoft.VisualStudio.TestTools.UnitTesting;
using NYSS_Bot.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace NYSS_BotTests.Model
{
    [TestClass()]
    public class KickReasonsTests
    {
        

        [TestMethod()]
        public void SetNumberMissedClasses_Int32MaxValue_CheckIsCorrectValueInDictionary()
        {
            KickReasons.SetNumberMissedClasses(Int32.MaxValue);
            string expected = $"Пропуск более {Int32.MaxValue} занятий";
            string actual = KickReasons.kickReasons[1];
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void SetNumberLaggedLectures_Int32MaxValue_CheckIsCorrectValueInDictionary()
        {
            KickReasons.SetNumberLaggedLectures(Int32.MaxValue);
            string expected = $"Отставание от общей группы на {Int32.MaxValue} и более лекций";
            string actual = KickReasons.kickReasons[3];
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void GetAllValues_SetMissedClasses_3_SetNumberLaggedLectures_121_GetCorrectString()
        {
            KickReasons.SetNumberMissedClasses(3);
            KickReasons.SetNumberLaggedLectures(121);
            string expected = "0 - Систематическое нарушение установленных правил\n" +
                              "1 - Пропуск более 3 занятий\n" +
                              "2 - Истечение срока проведения курса\n" +
                              "3 - Отставание от общей группы на 121 и более лекций\n" +
                              "4 - Изменение списка авторизованных пользователей\n" +
                              "5 - По заданному расписанию\n";

            string actual = KickReasons.GetAllValues();
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void GetAllValues_SetMissedClasses_Negative_SetNumberLaggedLectures_Negative_GetCorrectString()
        {
            KickReasons.SetNumberMissedClasses(-1);
            KickReasons.SetNumberLaggedLectures(-121);
            string expected = "0 - Систематическое нарушение установленных правил\n" +
                              "1 - Пропуск более 0 занятий\n" +
                              "2 - Истечение срока проведения курса\n" +
                              "3 - Отставание от общей группы на 0 и более лекций\n" +
                              "4 - Изменение списка авторизованных пользователей\n" +
                              "5 - По заданному расписанию\n";

            string actual = KickReasons.GetAllValues();
            Assert.AreEqual(expected, actual);
        }
    }
}
