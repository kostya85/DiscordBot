﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Text;
using System.Threading.Tasks;
using Discord;
using Discord.WebSocket;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NYSS_Bot.Model;

namespace NYSS_BotTests.Model
{
    [TestClass()]
    public class UsersTests
    {

        [TestMethod()]
        public void Test1()
        {
            var gu1 = new FakeGuildUser( 1);
            var gu2 = new FakeGuildUser( 2);
            var gu3 = new FakeGuildUser( 3);
            var u1 = new User {Id = 1};
            var u2 = new User {Id = 2};
            var u3 = new User {Id = 3};

            var dict = new Dictionary<User, IGuildUser>();
            dict.Add(u1, gu1);
            dict.Add(u2, gu2);
            dict.Add(u3, gu3);

            Users.AddAll(dict);

            Assert.IsTrue(Users.TryGet(u1, out IGuildUser guildUser));
            Assert.AreEqual(gu1, guildUser);

            Assert.IsTrue(Users.TryGet(u2.Id, out guildUser));
            Assert.AreEqual(gu2, guildUser);

            Assert.IsTrue(Users.TryGet(gu3, out User user));
            Assert.AreEqual(u3, user);

            Users.RemoveIfExists(u1.Id);
            Assert.IsFalse(Users.TryGet(u1.Id, out guildUser));
            Assert.IsFalse(Users.TryGet(gu1.Id, out user));
        }



        private class FakeGuildUser : IGuildUser
        {
            public FakeGuildUser(ulong id)
            {
                Id = id;
            }
            public ulong Id { get; }
            public DateTimeOffset CreatedAt { get; }
            public string Mention { get; }
            public IActivity Activity { get; }
            public UserStatus Status { get; }
            public IImmutableSet<ClientType> ActiveClients { get; }
            public string GetAvatarUrl(ImageFormat format = ImageFormat.Auto, ushort size = 128)
            {
                throw new NotImplementedException();
            }

            public string GetDefaultAvatarUrl()
            {
                throw new NotImplementedException();
            }

            public Task<IDMChannel> GetOrCreateDMChannelAsync(RequestOptions options = null)
            {
                throw new NotImplementedException();
            }

            public string AvatarId { get; }
            public string Discriminator { get; }
            public ushort DiscriminatorValue { get; }
            public bool IsBot { get; }
            public bool IsWebhook { get; }
            public string Username { get; }
            public bool IsDeafened { get; }
            public bool IsMuted { get; }
            public bool IsSelfDeafened { get; }
            public bool IsSelfMuted { get; }
            public bool IsSuppressed { get; }
            public IVoiceChannel VoiceChannel { get; }
            public string VoiceSessionId { get; }
            public bool IsStreaming { get; }
            public ChannelPermissions GetPermissions(IGuildChannel channel)
            {
                throw new NotImplementedException();
            }

            public Task KickAsync(string reason = null, RequestOptions options = null)
            {
                throw new NotImplementedException();
            }

            public Task ModifyAsync(Action<GuildUserProperties> func, RequestOptions options = null)
            {
                throw new NotImplementedException();
            }

            public Task AddRoleAsync(IRole role, RequestOptions options = null)
            {
                throw new NotImplementedException();
            }

            public Task AddRolesAsync(IEnumerable<IRole> roles, RequestOptions options = null)
            {
                throw new NotImplementedException();
            }

            public Task RemoveRoleAsync(IRole role, RequestOptions options = null)
            {
                throw new NotImplementedException();
            }

            public Task RemoveRolesAsync(IEnumerable<IRole> roles, RequestOptions options = null)
            {
                throw new NotImplementedException();
            }

            public DateTimeOffset? JoinedAt { get; }
            public string Nickname { get; }
            public GuildPermissions GuildPermissions { get; }
            public IGuild Guild { get; }
            public ulong GuildId { get; }
            public DateTimeOffset? PremiumSince { get; }
            public IReadOnlyCollection<ulong> RoleIds { get; }
        }
    }
}
