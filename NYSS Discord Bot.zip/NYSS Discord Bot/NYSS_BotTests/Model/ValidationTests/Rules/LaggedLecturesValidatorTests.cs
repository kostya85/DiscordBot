﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using NYSS_Bot.Helpers;
using NYSS_Bot.Model;
using NYSS_Bot.Model.Validation.Rules;
using System.Reflection;

namespace NYSS_BotTests.Model.ValidationTests.Rules
{
    [TestClass()]
    public class LaggedLecturesValidatorTests
    {     
        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает true,
        /// если ученик открыл текущую лекцию (которую только прошли).
        /// Тестовые параметры: 
        /// последняя открытая учеником лекция: LastOpenedLecture = "1_5";
        /// лекция, которую необходимо открыть: requiredLecture = 5; 
        /// допустимое отставание: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserOpenCurrentLection()
        {
            string kickReason = "";
            User testUser = new User() { LastOpenedLecture = "1_5" };
            LaggedLecturesValidator LaggedLecturesValidatorTest = new LaggedLecturesValidator();
            LaggedLecturesValidatorTest.SetPrivate("requiredLecture", 5);
            LaggedLecturesValidatorTest.SetPrivate("acceptableLag", 3); 
            List<string> testList = new List<string>() {
                "1_1", "1_2", "1_3", "1_4", "1_5", "1_6", "1_7", "1_8", "1_9", "1_10", "2_10"
            };
            LaggedLecturesValidatorTest.SetPrivate("listAllLectionFromSchedule", testList);
            Assert.IsTrue(LaggedLecturesValidatorTest.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает true, 
        /// если ученик открыл необходимое количество лекций (отстал на 2 лекции).
        /// Тестовые параметры: 
        /// последняя открытая учеником лекция: LastOpenedLecture = "1_4";
        /// лекция, которую необходимо открыть: requiredLecture = 5; 
        /// допустимое отставание: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserRequiredAmountLection()
        {
            string kickReason = "";
            User testUser = new User() { LastOpenedLecture = "1_4" };
            LaggedLecturesValidator LaggedLecturesValidatorTest = new LaggedLecturesValidator();
            LaggedLecturesValidatorTest.SetPrivate("requiredLecture", 5);
            LaggedLecturesValidatorTest.SetPrivate("acceptableLag", 3);
            List<string> testList = new List<string>() {
                "1_1", "1_2", "1_3", "1_4", "1_5", "1_6", "1_7", "1_8", "1_9", "1_10", "2_10"
            };
            LaggedLecturesValidatorTest.SetPrivate("listAllLectionFromSchedule", testList);
            Assert.IsTrue(LaggedLecturesValidatorTest.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает true, 
        /// если ученик открыл пограничное необходимое количество лекций (отстал на 2 лекции).
        /// Тестовые параметры: 
        /// последняя открытая учеником лекция: LastOpenedLecture = "1_3";
        /// лекция, которую необходимо открыть: requiredLecture = 5; 
        /// допустимое отставание: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserBorderRequiredAmountLection()
        {
            string kickReason = "";
            User testUser = new User() { LastOpenedLecture = "1_3" };
            LaggedLecturesValidator LaggedLecturesValidatorTest = new LaggedLecturesValidator();
            LaggedLecturesValidatorTest.SetPrivate("requiredLecture", 5);
            LaggedLecturesValidatorTest.SetPrivate("acceptableLag", 3);
            List<string> testList = new List<string>() {
                "1_1", "1_2", "1_3", "1_4", "1_5", "1_6", "1_7", "1_8", "1_9", "1_10", "2_10" 
            };
            LaggedLecturesValidatorTest.SetPrivate("listAllLectionFromSchedule", testList);
            Assert.IsTrue(LaggedLecturesValidatorTest.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает false, 
        /// если ученик не открыл необходимое количество лекций (отстал на 3 лекции).
        /// Тестовые параметры: 
        /// последняя открытая учеником лекция: LastOpenedLecture = "1_2";
        /// лекция, которую необходимо открыть: requiredLecture = 8; 
        /// допустимое отставание: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserDontOpenRequiredLection()
        {
            string kickReason = "";
            User testUser = new User() { LastOpenedLecture = "1_2" };
            LaggedLecturesValidator LaggedLecturesValidatorTest = new LaggedLecturesValidator();
            LaggedLecturesValidatorTest.SetPrivate("requiredLecture", 8);
            LaggedLecturesValidatorTest.SetPrivate("acceptableLag", 3);
            List<string> testList = new List<string>() {
                "1_1", "1_2", "1_3", "1_4", "1_5", "1_6", "1_7", "1_8", "1_9", "1_10", "2_10"
            };
            LaggedLecturesValidatorTest.SetPrivate("listAllLectionFromSchedule", testList);
            Assert.IsFalse(LaggedLecturesValidatorTest.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает false, 
        /// если ученик не открыл приграничное необходимое количество лекций (отстал на 3 лекции).
        /// Тестовые параметры: 
        /// последняя открытая учеником лекция: LastOpenedLecture = "1_5";
        /// лекция, которую необходимо открыть: requiredLecture = 8;
        /// допустимое отставание: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserDontOpenRequiredLectionBorderCase()
        {
            string kickReason = "";
            User testUser = new User() { LastOpenedLecture = "1_5" };
            LaggedLecturesValidator LaggedLecturesValidatorTest = new LaggedLecturesValidator();
            LaggedLecturesValidatorTest.SetPrivate("requiredLecture", 8);
            LaggedLecturesValidatorTest.SetPrivate("acceptableLag", 3);
            List<string> testList = new List<string>() {
                "1_1", "1_2", "1_3", "1_4", "1_5", "1_6", "1_7", "1_8", "1_9", "1_10", "2_10"
            };
            LaggedLecturesValidatorTest.SetPrivate("listAllLectionFromSchedule", testList);
            Assert.IsFalse(LaggedLecturesValidatorTest.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() корректно устанавливает значение kickReason, 
        /// если ученик не открыл необходимое количество лекций (отстал на 3 лекции).
        /// Тестовые параметры: 
        /// последняя открытая учеником лекция: LastOpenedLecture = "1_2";
        /// лекция, которую необходимо открыть: requiredLecture = 8; 
        /// допустимое отставание: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckKickReasonValueMethodCheckForWhenUserDontOpenRequiredLection()
        {
            string kickReason = "";
            User testUser = new User() { LastOpenedLecture = "1_2" };
            LaggedLecturesValidator LaggedLecturesValidatorTest = new LaggedLecturesValidator();
            LaggedLecturesValidatorTest.SetPrivate("requiredLecture", 8);
            LaggedLecturesValidatorTest.SetPrivate("acceptableLag", 3); 
            List<string> testList = new List<string>() {
                "1_1", "1_2", "1_3", "1_4", "1_5", "1_6", "1_7", "1_8", "1_9", "1_10", "2_10"
            };
            LaggedLecturesValidatorTest.SetPrivate("listAllLectionFromSchedule", testList);
            LaggedLecturesValidatorTest.CheckFor(testUser, out kickReason);
            LaggedLecturesValidatorTest.SetPrivate("listAllLectionFromSchedule", testList);
            Assert.AreEqual("Отставание от общей группы на 3 и более лекций", kickReason);
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() корректно устанавливает значение kickReason, 
        /// если ученик не открыл приграничное необходимое количество лекций (отстал на 3 лекции).
        /// Тестовые параметры: 
        /// последняя открытая учеником лекция: LastOpenedLecture = "1_5";
        /// лекция, которую необходимо открыть: requiredLecture = 8; 
        /// допустимое отставание: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckKickReasonValueMethodCheckForWhenUserDontOpenRequiredLectionBorderCase()
        {
            string kickReason = "";
            User testUser = new User() { LastOpenedLecture = "1_5" };
            LaggedLecturesValidator LaggedLecturesValidatorTest = new LaggedLecturesValidator();
            LaggedLecturesValidatorTest.SetPrivate("requiredLecture", 8);
            LaggedLecturesValidatorTest.SetPrivate("acceptableLag", 3);
            List<string> testList = new List<string>() {
                "1_1", "1_2", "1_3", "1_4", "1_5", "1_6", "1_7", "1_8", "1_9", "1_10", "2_10"
            };
            LaggedLecturesValidatorTest.SetPrivate("listAllLectionFromSchedule", testList);
            LaggedLecturesValidatorTest.CheckFor(testUser, out kickReason);
            Assert.AreEqual("Отставание от общей группы на 3 и более лекций", kickReason);
        }
    }
}
