﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using NYSS_Bot.Helpers;
using NYSS_Bot.Model;
using NYSS_Bot.Model.Validation.Rules;
using System.Reflection;

namespace NYSS_BotTests.Model.ValidationTests.Rules
{
    [TestClass()]
    public class MissedLessonsValidatorTests
    {
        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает true, 
        /// если ученик пропустил допустимое количество лекций.
        /// Тестовые параметры: 
        /// лекция, которую необходимо открыть: MissedLessonsCount = 0; 
        /// допустимое отставание: acceptableNumberOfMissedLessons = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserMissedLessonsAcceptableNumberOfTime()
        {
            string kickReason = "";
            User testUser = new User() { MissedLessonsCount = 0 };
            MissedLessonsValidator MissedLessonsValidator = new MissedLessonsValidator();
            MissedLessonsValidator.SetPrivate("acceptableNumberOfMissedLessons", 3);
            Assert.IsTrue(MissedLessonsValidator.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает true, 
        /// если ученик пропустил приграничное допустимое количество лекций.
        /// Тестовые параметры: 
        /// лекция, которую необходимо открыть: MissedLessonsCount = 3; 
        /// допустимое отставание: acceptableNumberOfMissedLessons = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserMissedLessonsBorderAcceptableNumberOfTime()
        {
            string kickReason = "";
            User testUser = new User() { MissedLessonsCount = 3 };
            MissedLessonsValidator MissedLessonsValidator = new MissedLessonsValidator();
            MissedLessonsValidator.SetPrivate("acceptableNumberOfMissedLessons", 3);
            Assert.IsTrue(MissedLessonsValidator.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает false, 
        /// если ученик пропустил недопустимое количество лекций.
        /// Тестовые параметры: 
        /// лекция, которую необходимо открыть: MissedLessonsCount = 6; 
        /// допустимое отставание: acceptableNumberOfMissedLessons = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserMissedLessonsNonAcceptableNumberOfTime()
        {
            string kickReason = "";
            User testUser = new User() { MissedLessonsCount = 6 };
            MissedLessonsValidator MissedLessonsValidator = new MissedLessonsValidator();
            MissedLessonsValidator.SetPrivate("acceptableNumberOfMissedLessons", 3);
            Assert.IsFalse(MissedLessonsValidator.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает false, 
        /// если ученик пропустил приграничное недопустимое количество лекций.
        /// Тестовые параметры: 
        /// лекция, которую необходимо открыть: MissedLessonsCount = 4; 
        /// допустимое отставание: acceptableNumberOfMissedLessons = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserMissedLessonsBorderNonAcceptableNumberOfTime()
        {
            string kickReason = "";
            User testUser = new User() { MissedLessonsCount = 4 };
            MissedLessonsValidator MissedLessonsValidator = new MissedLessonsValidator();
            MissedLessonsValidator.SetPrivate("acceptableNumberOfMissedLessons", 3);
            Assert.IsFalse(MissedLessonsValidator.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() корректно устанавливает значение kickReason, 
        /// если ученик пропустил недопустимое количество лекций.
        /// Тестовые параметры: 
        /// лекция, которую необходимо открыть: MissedLessonsCount = 6; 
        /// допустимое отставание: acceptableNumberOfMissedLessons = 3.
        /// </summary>
        [TestMethod()]
        public void CheckKickReasonValueMethodCheckForWhenUserMissedLessonsNonAcceptableNumberOfTime()
        {
            string kickReason = "";
            User testUser = new User() { MissedLessonsCount = 6 };
            MissedLessonsValidator MissedLessonsValidator = new MissedLessonsValidator();
            MissedLessonsValidator.SetPrivate("acceptableNumberOfMissedLessons", 3);
            MissedLessonsValidator.CheckFor(testUser, out kickReason);
            Assert.AreEqual("Пропуск более 3 занятий", kickReason);
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() корректно устанавливает значение kickReason, 
        /// если ученик пропустил недопустимое количество лекций.
        /// Тестовые параметры: 
        /// лекция, которую необходимо открыть: MissedLessonsCount = 4; 
        /// допустимое отставание: acceptableNumberOfMissedLessons = 3.
        /// </summary>
        [TestMethod()]
        public void CheckKickReasonValueMethodCheckForWhenUserMissedLessonsBorderNonAcceptableNumberOfTime()
        {
            string kickReason = "";
            User testUser = new User() { MissedLessonsCount = 4 };
            MissedLessonsValidator MissedLessonsValidator = new MissedLessonsValidator();
            MissedLessonsValidator.SetPrivate("acceptableNumberOfMissedLessons", 3);
            MissedLessonsValidator.CheckFor(testUser, out kickReason);
            Assert.AreEqual("Пропуск более 3 занятий", kickReason);
        }        
    }
}
