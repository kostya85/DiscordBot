﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using NYSS_Bot.Helpers;
using NYSS_Bot.Model;
using NYSS_Bot.Model.Validation.Rules;
using System.Reflection;

namespace NYSS_BotTests.Model.ValidationTests.Rules
{
    [TestClass()]
    public class ViolatedRulesValidatorTests
    {
        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает true, 
        /// если ученик нарушал правила допустимое количество раз.
        /// Тестовые параметры: 
        /// количество нарушений учеником: ViolatedRulesCount = 0; 
        /// допустимое количество нарушений: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserViolatedRulesAcceptableNumberOfTimes()
        {
            string kickReason = "";
            User testUser = new User() { ViolatedRulesCount = 0 };
            ViolatedRulesValidator ViolatedRulesValidator = new ViolatedRulesValidator();
            ViolatedRulesValidator.SetPrivate("acceptableNumberOfViolations", 3);
            Assert.IsTrue(ViolatedRulesValidator.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает true, 
        /// если ученик нарушал правила приграничное допустимое количество раз.
        /// Тестовые параметры: 
        /// количество нарушений учеником: ViolatedRulesCount = 3; 
        /// допустимое количество нарушений: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserViolatedRulesBorderAcceptableNumberOfTimes()
        {
            string kickReason = "";
            User testUser = new User() { ViolatedRulesCount = 3 };
            ViolatedRulesValidator ViolatedRulesValidator = new ViolatedRulesValidator();
            ViolatedRulesValidator.SetPrivate("acceptableNumberOfViolations", 3);
            Assert.IsTrue(ViolatedRulesValidator.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает false, 
        /// если ученик нарушал правила недопустимое количество раз.
        /// Тестовые параметры: 
        /// количество нарушений учеником: ViolatedRulesCount = 6; 
        /// допустимое количество нарушений: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserViolatedRulesNonAcceptableNumberOfTimes()
        {
            string kickReason = "";
            User testUser = new User() { ViolatedRulesCount = 6 };
            ViolatedRulesValidator ViolatedRulesValidator = new ViolatedRulesValidator();
            ViolatedRulesValidator.SetPrivate("acceptableNumberOfViolations", 3);
            Assert.IsFalse(ViolatedRulesValidator.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() возвращает false, 
        /// если ученик нарушал правила приграничное недопустимое количество раз.
        /// Тестовые параметры: 
        /// количество нарушений учеником: ViolatedRulesCount = 4; 
        /// допустимое количество нарушений: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckReturnValueMethodCheckForWhenUserViolatedRulesBorderNonAcceptableNumberOfTimes()
        {
            string kickReason = "";
            User testUser = new User() { ViolatedRulesCount = 4 };
            ViolatedRulesValidator ViolatedRulesValidator = new ViolatedRulesValidator();
            ViolatedRulesValidator.SetPrivate("acceptableNumberOfViolations", 3);
            Assert.IsFalse(ViolatedRulesValidator.CheckFor(testUser, out kickReason));
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() корректно устанавливает значение kickReason, 
        /// если ученик нарушал правила недопустимое количество раз.
        /// Тестовые параметры: 
        /// количество нарушений учеником: ViolatedRulesCount = 6; 
        /// допустимое количество нарушений: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckKickReasonValueMethodCheckForWhenUserViolatedRulesNonAcceptableNumberOfTimes()
        {
            string kickReason = "";
            User testUser = new User() { ViolatedRulesCount = 6 };
            ViolatedRulesValidator ViolatedRulesValidator = new ViolatedRulesValidator();
            ViolatedRulesValidator.SetPrivate("acceptableNumberOfViolations", 3);
            ViolatedRulesValidator.CheckFor(testUser, out kickReason);
            Assert.AreEqual("Систематическое нарушение установленных правил", kickReason);
        }

        /// <summary>
        /// Метод проверяет, что CheckFor() корректно устанавливает значение kickReason, 
        /// если ученик нарушал правила приграничное недопустимое количество раз.
        /// Тестовые параметры: 
        /// количество нарушений учеником: ViolatedRulesCount = 4; 
        /// допустимое количество нарушений: acceptableLag = 3.
        /// </summary>
        [TestMethod()]
        public void CheckKickReasonValueMethodCheckForWhenUserViolatedRulesBorderNonAcceptableNumberOfTimes()
        {
            string kickReason = "";
            User testUser = new User() { ViolatedRulesCount = 4 };
            ViolatedRulesValidator ViolatedRulesValidator = new ViolatedRulesValidator();
            ViolatedRulesValidator.SetPrivate("acceptableNumberOfViolations", 3);
            ViolatedRulesValidator.CheckFor(testUser, out kickReason);
            Assert.AreEqual("Систематическое нарушение установленных правил", kickReason);
        }

    }
}
